import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { Strategy as FacebookStrategy } from 'passport-facebook';
import {
  getUserById,
  getUserByEmail,
  getUserByGoogleId,
  getUserByFacebookId,
  createUser,
  linkOAuthAccount,
  DbUser,
} from '../db/index.js';

export function configurePassport(): void {
  // Session serialization
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await getUserById(id);
      done(null, user);
    } catch (err) {
      done(err, null);
    }
  });

  // Google OAuth 2.0 Strategy
  const googleClientId = process.env.GOOGLE_CLIENT_ID;
  const googleClientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const googleCallbackUrl =
    process.env.GOOGLE_CALLBACK_URL || '/api/auth/google/callback';

  if (googleClientId && googleClientSecret) {
    passport.use(
      new GoogleStrategy(
        {
          clientID: googleClientId,
          clientSecret: googleClientSecret,
          callbackURL: googleCallbackUrl,
          proxy: true,
        },
        async (_accessToken, _refreshToken, profile, done) => {
          try {
            const googleId = profile.id;
            const email =
              profile.emails && profile.emails[0]
                ? profile.emails[0].value
                : null;
            const name =
              profile.displayName ||
              (profile.name
                ? `${profile.name.givenName || ''} ${profile.name.familyName || ''}`.trim()
                : 'Google User');

            // 1. Find user by google_id
            let user = await getUserByGoogleId(googleId);
            if (user) {
              return done(null, user);
            }

            // 2. If not found by google_id, check by email
            if (email) {
              user = await getUserByEmail(email);
              if (user) {
                // Link Google ID to existing user
                const updated = await linkOAuthAccount(user.id, {
                  googleId,
                  name: user.name || name,
                });
                return done(null, updated || user);
              }
            }

            // 3. Create a new user
            const newUser = await createUser({
              name: name || 'Google User',
              email: email || `${googleId}@google.oauth`,
              googleId,
            });

            return done(null, newUser);
          } catch (error) {
            console.error('[Google OAuth Strategy Error]:', error);
            return done(error as Error, undefined);
          }
        }
      )
    );
    console.log('[Passport] Google OAuth strategy configured successfully.');
  } else {
    console.log(
      '[Passport Notice] Google OAuth credentials (GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET) not set. Google login endpoint will notify users to set up credentials in .env.'
    );
  }

  // Facebook OAuth Strategy
  const facebookAppId = process.env.FACEBOOK_APP_ID;
  const facebookAppSecret = process.env.FACEBOOK_APP_SECRET;
  const facebookCallbackUrl =
    process.env.FACEBOOK_CALLBACK_URL || '/api/auth/facebook/callback';

  if (facebookAppId && facebookAppSecret) {
    passport.use(
      new FacebookStrategy(
        {
          clientID: facebookAppId,
          clientSecret: facebookAppSecret,
          callbackURL: facebookCallbackUrl,
          profileFields: ['id', 'displayName', 'emails', 'name'],
          proxy: true,
        },
        async (_accessToken, _refreshToken, profile, done) => {
          try {
            const facebookId = profile.id;
            const email =
              profile.emails && profile.emails[0]
                ? profile.emails[0].value
                : null;
            const name = profile.displayName || 'Facebook User';

            // 1. Find user by facebook_id
            let user = await getUserByFacebookId(facebookId);
            if (user) {
              return done(null, user);
            }

            // 2. If not found by facebook_id, check by email
            if (email) {
              user = await getUserByEmail(email);
              if (user) {
                const updated = await linkOAuthAccount(user.id, {
                  facebookId,
                  name: user.name || name,
                });
                return done(null, updated || user);
              }
            }

            // 3. Create a new user
            const newUser = await createUser({
              name: name || 'Facebook User',
              email: email || `${facebookId}@facebook.oauth`,
              facebookId,
            });

            return done(null, newUser);
          } catch (error) {
            console.error('[Facebook OAuth Strategy Error]:', error);
            return done(error as Error, undefined);
          }
        }
      )
    );
    console.log('[Passport] Facebook OAuth strategy configured successfully.');
  } else {
    console.log(
      '[Passport Notice] Facebook OAuth credentials (FACEBOOK_APP_ID / FACEBOOK_APP_SECRET) not set. Facebook login endpoint will notify users to set up credentials in .env.'
    );
  }
}
