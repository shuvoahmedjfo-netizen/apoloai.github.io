import { GoogleGenAI } from '@google/genai';

/**
 * Returns 3 intelligent, contextual fallback follow-up questions
 * based on response content and detected language.
 */
export function getFallbackSuggestions(lastResponse: string, userQuestion: string = ''): string[] {
  const combined = (lastResponse + ' ' + userQuestion).toLowerCase();
  const isBengali = /[\u0980-\u09FF]/.test(lastResponse + userQuestion);

  if (isBengali) {
    if (
      combined.includes('কোড') ||
      combined.includes('প্রোগ্রাম') ||
      combined.includes('error') ||
      combined.includes('ফাংশন')
    ) {
      return [
        'একটি কোড উদাহরণ দিন',
        'এটি কীভাবে রান করব?',
        'সাধারণ ভুলগুলো কী কী?',
      ];
    }
    if (combined.includes('কেন') || combined.includes('কীভাবে') || combined.includes('কিভাবে')) {
      return [
        'আরও বিস্তারিত ব্যাখ্যা করবেন?',
        'একটি বাস্তব উদাহরণ দিন',
        'এর সুবিধা ও অসুবিধা কি?',
      ];
    }
    return [
      'আরও বিস্তারিত বলুন',
      'একটি সহজ উদাহরণ দিন',
      'পরবর্তী পদক্ষেপ কি?',
    ];
  }

  // English contextual heuristics
  if (
    combined.includes('function') ||
    combined.includes('code') ||
    combined.includes('```') ||
    combined.includes('const ') ||
    combined.includes('import ') ||
    combined.includes('error')
  ) {
    return [
      'Can you show a code example?',
      'How do I test or debug this?',
      'What are common edge cases?',
    ];
  }

  if (
    combined.includes('why') ||
    combined.includes('how') ||
    combined.includes('difference') ||
    combined.includes('vs') ||
    combined.includes('compare')
  ) {
    return [
      'Can you give a practical example?',
      'What are the main pros and cons?',
      'How does this compare to alternatives?',
    ];
  }

  if (
    combined.includes('step') ||
    combined.includes('guide') ||
    combined.includes('create') ||
    combined.includes('build')
  ) {
    return [
      'What are the next steps?',
      'What are the best practices for this?',
      'Are there any common mistakes to avoid?',
    ];
  }

  return [
    'Can you explain this in more detail?',
    'Can you give a concrete example?',
    'What should I know next?',
  ];
}

/**
 * Uses Gemini with low latency to suggest 3 natural follow-up questions
 * strictly tailored to the last answer.
 */
export async function generateFollowUpSuggestions(
  ai: GoogleGenAI,
  lastResponse: string,
  userQuestion: string = ''
): Promise<string[]> {
  try {
    const cleanResponse = lastResponse.slice(0, 900);
    const cleanQuestion = (userQuestion || '').slice(0, 250);

    const isBengali = /[\u0980-\u09FF]/.test(cleanResponse + cleanQuestion);

    const prompt = isBengali
      ? `Based on this AI response to the user query "${cleanQuestion}":
"${cleanResponse}"

Suggest exactly 3 short, natural, relevant follow-up questions in Bengali (বাংলা) that the user might want to ask next.
Each question must be concise (under 8 words).
Respond ONLY with a JSON array of 3 strings: ["প্রশ্ন ১?", "প্রশ্ন ২?", "প্রশ্ন ৩?"]`
      : `Based on this AI response to the user query "${cleanQuestion}":
"${cleanResponse}"

Suggest exactly 3 short, natural, relevant follow-up questions in English that the user might want to ask next.
Each question must be concise (under 8 words).
Respond ONLY with a JSON array of 3 strings: ["Question 1?", "Question 2?", "Question 3?"]`;

    const candidateModels = [
      'gemini-3.6-flash',
      'gemini-3.8-flash',
      'gemini-flash-latest',
      'gemini-3.1-flash-lite',
      'gemini-3.1-pro-preview',
    ];

    for (const model of candidateModels) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
          config: {
            temperature: 0.6,
            responseMimeType: 'application/json',
          },
        });

        if (response && response.text) {
          const raw = response.text.trim();
          const match = raw.match(/\[[\s\S]*\]/);
          if (match) {
            const parsed = JSON.parse(match[0]);
            if (Array.isArray(parsed) && parsed.length >= 3) {
              const cleaned = parsed
                .slice(0, 3)
                .map((q) =>
                  typeof q === 'string'
                    ? q.trim().replace(/^["'\d\.\-\s]+/, '').replace(/["']+$/, '')
                    : ''
                )
                .filter((q) => q.length > 0);

              if (cleaned.length === 3) {
                return cleaned;
              }
            }
          }
        }
      } catch {
        continue;
      }
    }
  } catch (err) {
    console.warn('[Suggestions Error]:', err);
  }

  return getFallbackSuggestions(lastResponse, userQuestion);
}
