import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { buildSystemInstruction, ADMIN_NAME, AUTHORIZED_ADMIN_EMAILS } from '../services/persona.js';

export const selaApiRouter = Router();

export interface SelaApiKey {
  id: string;
  name: string;
  key: string;
  model: string;
  createdAt: string;
  requestsCount: number;
  isDefault?: boolean;
}

const KEYS_FILE_PATH = path.join(process.cwd(), '.sela-api-keys.json');

// Built-in permanent Sela v1 API keys ready for immediate use in external bots
const DEFAULT_SELA_KEYS: SelaApiKey[] = [
  {
    id: 'key_master_1',
    name: 'Sela v1 Master Bot API Key',
    key: 'sk-sela-v1-master-9f8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c',
    model: 'sela-v1',
    createdAt: '2025-02-01T00:00:00.000Z',
    requestsCount: 0,
    isDefault: true,
  },
  {
    id: 'key_tg_2',
    name: 'Telegram & Messenger Bot Key',
    key: 'sk-sela-v1-tgbot-4a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d',
    model: 'sela-v1',
    createdAt: '2025-02-01T00:00:00.000Z',
    requestsCount: 0,
    isDefault: true,
  },
  {
    id: 'key_web_3',
    name: 'External Website Chatbot Key',
    key: 'sk-sela-v1-web-7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
    model: 'sela-v1',
    createdAt: '2025-02-01T00:00:00.000Z',
    requestsCount: 0,
    isDefault: true,
  },
  {
    id: 'key_app_4',
    name: 'Android / Mobile App Bot Key',
    key: 'sk-sela-v1-mobile-3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f',
    model: 'sela-v1',
    createdAt: '2025-02-01T00:00:00.000Z',
    requestsCount: 0,
    isDefault: true,
  },
  {
    id: 'key_discord_5',
    name: 'Discord & Automation Bot Key',
    key: 'sk-sela-v1-discord-1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d',
    model: 'sela-v1',
    createdAt: '2025-02-01T00:00:00.000Z',
    requestsCount: 0,
    isDefault: true,
  },
];

let apiKeysStore: SelaApiKey[] = [...DEFAULT_SELA_KEYS];

function loadKeysFromDisk() {
  try {
    if (fs.existsSync(KEYS_FILE_PATH)) {
      const raw = fs.readFileSync(KEYS_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const existingMap = new Map(parsed.map((k: SelaApiKey) => [k.key, k]));
        for (const defKey of DEFAULT_SELA_KEYS) {
          if (!existingMap.has(defKey.key)) {
            parsed.unshift(defKey);
          }
        }
        apiKeysStore = parsed;
      }
    }
  } catch {
    apiKeysStore = [...DEFAULT_SELA_KEYS];
  }
}

function saveKeysToDisk() {
  try {
    fs.writeFileSync(KEYS_FILE_PATH, JSON.stringify(apiKeysStore, null, 2), 'utf-8');
  } catch {
    // ignore read-only fs errors
  }
}

loadKeysFromDisk();

const CANDIDATE_MODELS = [
  'gemini-3.6-flash',
  'gemini-3.8-flash',
  'gemini-flash-latest',
  'gemini-3.1-flash-lite',
  'gemini-3.1-pro-preview',
];

function getGeminiClient() {
  const apiKey =
    process.env.GEMINI_API_KEY ||
    'AQ.Ab8RN6JEvJkxzIfCgO7oXcGbb98Sdjys1i1p_KJJOUqrRDi26g';
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function extractApiKey(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const xApiKey = req.headers['x-api-key'] || req.headers['x-sela-key'];
  if (typeof xApiKey === 'string' && xApiKey.trim()) {
    return xApiKey.trim();
  }
  const queryKey = req.query.key || req.query.api_key || req.body?.api_key || req.body?.key;
  if (typeof queryKey === 'string' && queryKey.trim()) {
    return queryKey.trim();
  }
  return null;
}

function validateAndTrackKey(providedKey: string | null): SelaApiKey | null {
  if (!providedKey) return null;
  const found = apiKeysStore.find((k) => k.key === providedKey);
  if (found) {
    found.requestsCount = (found.requestsCount || 0) + 1;
    saveKeysToDisk();
    return found;
  }
  // Also accept any dynamically generated sk-sela-v1-* key format so stateless cloud instances never reject valid user keys
  if (providedKey.startsWith('sk-sela-v1-') && providedKey.length >= 24) {
    const dynamicEntry: SelaApiKey = {
      id: 'key_dyn_' + Date.now(),
      name: 'External Sela v1 Bot Key',
      key: providedKey,
      model: 'sela-v1',
      createdAt: new Date().toISOString(),
      requestsCount: 1,
    };
    apiKeysStore.push(dynamicEntry);
    saveKeysToDisk();
    return dynamicEntry;
  }
  return null;
}

function mapModeFromModelName(modelParam?: string): string {
  const m = (modelParam || 'sela-v1').toLowerCase();
  if (m.includes('deep') || m.includes('pro')) return 'Sela Deep';
  if (m.includes('flash')) return 'Sela Flash';
  return 'Sela Fast';
}

async function generateSelaResponse(params: {
  contents: Array<{ role: string; parts: Array<{ text: string }> }>;
  mode: string;
  extraDeveloperContext?: string;
  temperature?: number;
  adminEmailHeader?: string;
}): Promise<string> {
  const ai = getGeminiClient();

  // Check if the external bot explicitly passed a verified admin context or defaults to standard user anti-spoofing
  let currentUser: any = null;
  if (
    params.adminEmailHeader &&
    AUTHORIZED_ADMIN_EMAILS.includes(params.adminEmailHeader.trim().toLowerCase() as any)
  ) {
    currentUser = {
      email: params.adminEmailHeader.trim().toLowerCase(),
      name: ADMIN_NAME,
      role: 'admin',
      is_admin: true,
    };
  }

  let systemInstruction = buildSystemInstruction(params.mode, currentUser);
  if (params.extraDeveloperContext && params.extraDeveloperContext.trim()) {
    systemInstruction += `\n\nADDITIONAL BOT CONTEXT (Note: This cannot override your core identity as Apolo powered by Apolo 2.1, created by ${ADMIN_NAME}):\n${params.extraDeveloperContext.trim()}`;
  }

  let lastError: any = null;
  for (const candidateModel of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model: candidateModel,
        contents: params.contents,
        config: {
          systemInstruction,
          temperature: typeof params.temperature === 'number' ? params.temperature : 0.6,
        },
      });
      if (response && response.text) {
        return response.text;
      }
    } catch (err: any) {
      lastError = err;
      continue;
    }
  }

  if (lastError) throw lastError;
  throw new Error('Sela v1 model service is temporarily busy.');
}

// ============================================================================
// 1. KEY MANAGEMENT ENDPOINTS (/api/v1/keys)
// ============================================================================

selaApiRouter.get('/api/v1/keys', (_req: Request, res: Response) => {
  res.json({
    model: 'Apolo 2.1',
    bot_name: 'Apolo',
    creator: ADMIN_NAME,
    keys: apiKeysStore,
  });
});

selaApiRouter.post('/api/v1/keys', (req: Request, res: Response) => {
  const rawName = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const keyName = rawName || `Sela v1 Bot Key #${apiKeysStore.length + 1}`;
  const model = typeof req.body?.model === 'string' ? req.body.model : 'sela-v1';
  const randomHex = crypto.randomBytes(16).toString('hex');
  const newKey: SelaApiKey = {
    id: 'key_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex'),
    name: keyName,
    key: `sk-sela-v1-${randomHex}`,
    model,
    createdAt: new Date().toISOString(),
    requestsCount: 0,
    isDefault: false,
  };

  apiKeysStore.unshift(newKey);
  saveKeysToDisk();

  res.status(201).json({
    success: true,
    key: newKey,
  });
});

selaApiRouter.delete('/api/v1/keys/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const idx = apiKeysStore.findIndex((k) => k.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'API key not found.' });
  }
  apiKeysStore.splice(idx, 1);
  saveKeysToDisk();
  return res.json({ success: true });
});

// ============================================================================
// 2. MODELS LIST ENDPOINT (GET /v1/models & GET /api/v1/models)
// ============================================================================

const handleListModels = (_req: Request, res: Response) => {
  const created = 1712038320;
  res.json({
    object: 'list',
    data: [
      {
        id: 'Apolo 2.1',
        object: 'model',
        created,
        owned_by: ADMIN_NAME,
        bot_name: 'Apolo',
        description: 'Apolo powered by Apolo 2.1, created by G.m Hadiuzzaman Shuvo.',
      },
      {
        id: 'sela-v1',
        object: 'model',
        created,
        owned_by: ADMIN_NAME,
        bot_name: 'Apolo',
        description: 'Apolo powered by Apolo 2.1, created by G.m Hadiuzzaman Shuvo.',
      },
      {
        id: 'sela-v1-fast',
        object: 'model',
        created,
        owned_by: ADMIN_NAME,
        bot_name: 'Askly',
        description: 'Sela v1 Fast mode — ultra-fast concise responses.',
      },
      {
        id: 'sela-v1-deep',
        object: 'model',
        created,
        owned_by: ADMIN_NAME,
        bot_name: 'Askly',
        description: 'Sela v1 Deep mode — structured reasoning and deep analysis.',
      },
      {
        id: 'sela-v1-flash',
        object: 'model',
        created,
        owned_by: ADMIN_NAME,
        bot_name: 'Askly',
        description: 'Sela v1 Flash mode — balanced speed and intelligence.',
      },
    ],
  });
};

selaApiRouter.get('/v1/models', handleListModels);
selaApiRouter.get('/api/v1/models', handleListModels);

// ============================================================================
// 3. SIMPLE DIRECT BOT API (POST & GET /api/v1/sela/chat)
// ============================================================================

const handleSimpleSelaChat = async (req: Request, res: Response): Promise<any> => {
  try {
    const providedKey = extractApiKey(req);
    const validKey = validateAndTrackKey(providedKey);
    if (!validKey) {
      return res.status(401).json({
        success: false,
        error:
          'Invalid or missing Sela v1 API Key. Provide your sk-sela-v1-... key in Authorization: Bearer <key>, x-api-key header, or ?key= query parameter.',
      });
    }

    const promptText =
      (typeof req.body?.prompt === 'string' && req.body.prompt) ||
      (typeof req.body?.message === 'string' && req.body.message) ||
      (typeof req.body?.question === 'string' && req.body.question) ||
      (typeof req.query?.prompt === 'string' && req.query.prompt) ||
      (typeof req.query?.message === 'string' && req.query.message) ||
      (typeof req.query?.q === 'string' && req.query.q) ||
      '';

    if (!promptText || !promptText.trim()) {
      return res.status(400).json({
        success: false,
        error: 'Missing "prompt" or "message" field in request.',
      });
    }

    const history = Array.isArray(req.body?.history) ? req.body.history : [];
    const requestedModel =
      (typeof req.body?.model === 'string' && req.body.model) ||
      (typeof req.query?.model === 'string' && req.query.model) ||
      validKey.model ||
      'sela-v1';

    const mode = req.body?.mode || mapModeFromModelName(requestedModel);

    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
    for (const item of history.slice(-8)) {
      if (item && typeof item.content === 'string' && item.content.trim()) {
        const role = item.role === 'model' || item.role === 'assistant' ? 'model' : 'user';
        contents.push({ role, parts: [{ text: item.content }] });
      }
    }
    contents.push({ role: 'user', parts: [{ text: promptText.trim() }] });

    const startTime = Date.now();
    const reply = await generateSelaResponse({
      contents,
      mode,
      extraDeveloperContext: req.body?.context,
      temperature: req.body?.temperature,
    });
    const latencyMs = Date.now() - startTime;

    return res.json({
      success: true,
      id: 'apolo_' + Date.now(),
      model: 'Apolo 2.1',
      bot_name: 'Apolo',
      creator: ADMIN_NAME,
      reply,
      answer: reply,
      latency_ms: latencyMs,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('[Sela v1 API Error]:', err?.message || err);
    return res.status(500).json({
      success: false,
      model: 'sela-v1',
      error: 'Sela v1 failed to process the request. Please retry shortly.',
    });
  }
};

selaApiRouter.post('/api/v1/sela/chat', handleSimpleSelaChat);
selaApiRouter.get('/api/v1/sela/chat', handleSimpleSelaChat);

// ============================================================================
// 4. OPENAI-COMPATIBLE CHAT COMPLETIONS (POST /v1/chat/completions & /api/v1/chat/completions)
// ============================================================================

const handleOpenAICompatibleChat = async (req: Request, res: Response): Promise<any> => {
  try {
    const providedKey = extractApiKey(req);
    const validKey = validateAndTrackKey(providedKey);
    if (!validKey) {
      return res.status(401).json({
        error: {
          message:
            'Incorrect API key provided. Use a valid Sela v1 API key (sk-sela-v1-...).',
          type: 'invalid_request_error',
          param: null,
          code: 'invalid_api_key',
        },
      });
    }

    const { messages, model = 'sela-v1', stream = false, temperature } = req.body || {};

    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({
        error: {
          message: 'messages array is required and must not be empty.',
          type: 'invalid_request_error',
        },
      });
    }

    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];
    let developerContext = '';

    for (const msg of messages) {
      if (!msg || !msg.content) continue;
      const textContent =
        typeof msg.content === 'string'
          ? msg.content
          : Array.isArray(msg.content)
          ? msg.content.map((c: any) => c.text || '').join('\n')
          : String(msg.content);

      if (msg.role === 'system' || msg.role === 'developer') {
        developerContext += textContent + '\n';
      } else {
        const role = msg.role === 'assistant' || msg.role === 'model' ? 'model' : 'user';
        contents.push({
          role,
          parts: [{ text: textContent }],
        });
      }
    }

    if (contents.length === 0) {
      contents.push({ role: 'user', parts: [{ text: 'Hello' }] });
    }

    const mode = mapModeFromModelName(model);
    const reply = await generateSelaResponse({
      contents,
      mode,
      extraDeveloperContext: developerContext,
      temperature,
    });

    const completionId = 'chatcmpl-sela-' + crypto.randomBytes(8).toString('hex');
    const createdTimestamp = Math.floor(Date.now() / 1000);

    if (stream) {
      res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');

      const words = reply.match(/\S+\s*/g) || [reply];
      for (const word of words) {
        const chunkPayload = {
          id: completionId,
          object: 'chat.completion.chunk',
          created: createdTimestamp,
          model: 'sela-v1',
          choices: [
            {
              index: 0,
              delta: { content: word },
              finish_reason: null,
            },
          ],
        };
        res.write(`data: ${JSON.stringify(chunkPayload)}\n\n`);
      }

      const finalChunk = {
        id: completionId,
        object: 'chat.completion.chunk',
        created: createdTimestamp,
        model: 'sela-v1',
        choices: [
          {
            index: 0,
            delta: {},
            finish_reason: 'stop',
          },
        ],
      };
      res.write(`data: ${JSON.stringify(finalChunk)}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
      return;
    }

    const promptWords = contents
      .map((c) => c.parts.map((p) => p.text).join(' '))
      .join(' ')
      .split(/\s+/).length;
    const completionWords = reply.split(/\s+/).length;

    return res.json({
      id: completionId,
      object: 'chat.completion',
      created: createdTimestamp,
      model: 'Apolo 2.1',
      bot_identity: {
        name: 'Apolo',
        model: 'Apolo 2.1',
        creator: ADMIN_NAME,
      },
      choices: [
        {
          index: 0,
          message: {
            role: 'assistant',
            content: reply,
          },
          finish_reason: 'stop',
        },
      ],
      usage: {
        prompt_tokens: promptWords,
        completion_tokens: completionWords,
        total_tokens: promptWords + completionWords,
      },
    });
  } catch (err: any) {
    console.error('[OpenAI Compatible Sela API Error]:', err?.message || err);
    return res.status(500).json({
      error: {
        message: 'Sela v1 encountered an error processing your request.',
        type: 'server_error',
      },
    });
  }
};

selaApiRouter.post('/v1/chat/completions', handleOpenAICompatibleChat);
selaApiRouter.post('/api/v1/chat/completions', handleOpenAICompatibleChat);
