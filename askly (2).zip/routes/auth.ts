import { Router, Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import passport from 'passport';
import {
  createUser,
  getUserByEmail,
  getUserById,
  DbUser,
} from '../db/index.js';
import { authRateLimiter } from '../middleware/rateLimiter.js';
import { generateUserToken, verifyUserToken } from '../services/persona.js';

export const authRouter = Router();

// Sanitize user object before sending to client (never send password_hash)
function sanitizeUser(user: DbUser) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role || 'user',
    isAdmin: user.role === 'admin' || Boolean(user.is_admin),
    hasGoogleAuth: Boolean(user.google_id),
    hasFacebookAuth: Boolean(user.facebook_id),
    created_at: user.created_at,
  };
}

// Simple email validation regex
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// 1. SIGN UP: POST /api/auth/signup
authRouter.post(
  '/signup',
  authRateLimiter,
  async (req: Request, res: Response): Promise<any> => {
    try {
      const { name, email, password } = req.body;

      if (!name || typeof name !== 'string' || name.trim().length === 0) {
        return res.status(400).json({ error: 'Please provide your full name.' });
      }

      if (!email || typeof email !== 'string' || !EMAIL_REGEX.test(email.trim())) {
        return res.status(400).json({ error: 'Please enter a valid email address.' });
      }

      if (!password || typeof password !== 'string' || password.length < 8) {
        return res.status(400).json({
          error: 'Password must be at least 8 characters long.',
        });
      }

      const normalizedEmail = email.trim().toLowerCase();

      // Check if user already exists
      const existingUser = await getUserByEmail(normalizedEmail);
      if (existingUser) {
        return res.status(400).json({
          error: 'An account with this email address already exists. Please log in.',
        });
      }

      // Hash password using bcrypt
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(password, saltRounds);

      // Create new user in PostgreSQL database
      const newUser = await createUser({
        name: name.trim(),
        email: normalizedEmail,
        passwordHash,
      });

      // Establish session
      req.login(newUser, (err) => {
        if (err) {
          console.error('[Signup Session Error]:', err);
          return res.status(500).json({ error: 'Account created, but failed to log in automatically.' });
        }
        (req.session as any).userId = newUser.id;
        const token = generateUserToken(newUser.id);

        return res.status(201).json({
          message: 'Account created successfully!',
          user: sanitizeUser(newUser),
          token,
        });
      });
    } catch (error: any) {
      console.error('[Signup Error]:', error);
      return res.status(500).json({
        error: 'An unexpected error occurred during sign up. Please try again.',
      });
    }
  }
);

// 2. LOGIN: POST /api/auth/login
authRouter.post(
  '/login',
  authRateLimiter,
  async (req: Request, res: Response): Promise<any> => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({
          error: 'Email and password are required.',
        });
      }

      const normalizedEmail = email.trim().toLowerCase();
      const user = await getUserByEmail(normalizedEmail);

      if (!user || !user.password_hash) {
        return res.status(401).json({
          error: 'Invalid email or password.',
        });
      }

      // Verify password
      const isMatch = await bcrypt.compare(password, user.password_hash);
      if (!isMatch) {
        return res.status(401).json({
          error: 'Invalid email or password.',
        });
      }

      // Log the user into session
      req.login(user, (err) => {
        if (err) {
          console.error('[Login Session Error]:', err);
          return res.status(500).json({ error: 'Failed to establish session.' });
        }
        (req.session as any).userId = user.id;
        const token = generateUserToken(user.id);

        return res.json({
          message: 'Logged in successfully!',
          user: sanitizeUser(user),
          token,
        });
      });
    } catch (error: any) {
      console.error('[Login Error]:', error);
      return res.status(500).json({
        error: 'An error occurred while logging in. Please try again.',
      });
    }
  }
);

// 3. LOGOUT: POST /api/auth/logout
authRouter.post('/logout', (req: Request, res: Response) => {
  req.logout((err) => {
    if (err) {
      console.error('[Logout Error]:', err);
    }
    req.session.destroy((destroyErr) => {
      if (destroyErr) {
        console.error('[Session Destroy Error]:', destroyErr);
      }
      res.clearCookie('askly.sid');
      return res.json({ message: 'Logged out successfully.' });
    });
  });
});

// 4. CURRENT USER CHECK: GET /api/auth/me
authRouter.get('/me', async (req: Request, res: Response): Promise<any> => {
  try {
    if (req.isAuthenticated && req.isAuthenticated() && req.user) {
      const user = req.user as DbUser;
      return res.json({ user: sanitizeUser(user), token: generateUserToken(user.id) });
    }

    // Check Bearer token in header
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.slice(7).trim();
      const userId = verifyUserToken(token);
      if (userId) {
        const user = await getUserById(userId);
        if (user) {
          req.user = user;
          return res.json({ user: sanitizeUser(user), token: generateUserToken(user.id) });
        }
      }
    }

    const sessionUserId = (req.session as any)?.userId;
    if (sessionUserId) {
      const user = await getUserById(sessionUserId);
      if (user) {
        req.user = user;
        return res.json({ user: sanitizeUser(user), token: generateUserToken(user.id) });
      }
    }

    return res.json({ user: null });
  } catch (error: any) {
    console.error('[Auth Check Error]:', error);
    return res.status(500).json({ error: 'Failed to check authentication status.' });
  }
});

// 5. GOOGLE OAUTH ROUTES
authRouter.get('/google', (req: Request, res: Response, next: NextFunction) => {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return res.status(503).json({
      error:
        'Google OAuth is not configured. Please add GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET to your .env file.',
    });
  }
  passport.authenticate('google', {
    scope: ['profile', 'email'],
    prompt: 'select_account',
  })(req, res, next);
});

authRouter.get(
  '/google/callback',
  (req: Request, res: Response, next: NextFunction) => {
    if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
      return res.redirect('/?error=google_not_configured');
    }

    passport.authenticate('google', (err: any, user: DbUser | false, info: any) => {
      if (err || !user) {
        console.error('[Google Callback Auth Failure]:', err || info);
        return res.redirect('/?error=oauth_failed');
      }

      req.login(user, (loginErr) => {
        if (loginErr) {
          console.error('[Google Login Session Error]:', loginErr);
          return res.redirect('/?error=session_error');
        }
        (req.session as any).userId = user.id;
        const frontendUrl = process.env.FRONTEND_URL || '/';
        return res.redirect(frontendUrl);
      });
    })(req, res, next);
  }
);

// 6. FACEBOOK OAUTH ROUTES
authRouter.get('/facebook', (req: Request, res: Response, next: NextFunction) => {
  if (!process.env.FACEBOOK_APP_ID || !process.env.FACEBOOK_APP_SECRET) {
    return res.status(503).json({
      error:
        'Facebook OAuth is not configured. Please add FACEBOOK_APP_ID and FACEBOOK_APP_SECRET to your .env file.',
    });
  }
  passport.authenticate('facebook', {
    scope: ['email', 'public_profile'],
  })(req, res, next);
});

authRouter.get(
  '/facebook/callback',
  (req: Request, res: Response, next: NextFunction) => {
    if (!process.env.FACEBOOK_APP_ID || !process.env.FACEBOOK_APP_SECRET) {
      return res.redirect('/?error=facebook_not_configured');
    }

    passport.authenticate('facebook', (err: any, user: DbUser | false, info: any) => {
      if (err || !user) {
        console.error('[Facebook Callback Auth Failure]:', err || info);
        return res.redirect('/?error=oauth_failed');
      }

      req.login(user, (loginErr) => {
        if (loginErr) {
          console.error('[Facebook Login Session Error]:', loginErr);
          return res.redirect('/?error=session_error');
        }
        (req.session as any).userId = user.id;
        const frontendUrl = process.env.FRONTEND_URL || '/';
        return res.redirect(frontendUrl);
      });
    })(req, res, next);
  }
);
