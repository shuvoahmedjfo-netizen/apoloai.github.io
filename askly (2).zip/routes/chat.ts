import { Router, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import {
  saveChatMessage,
  getUserChatHistory,
  clearUserChatHistory,
} from '../db/index.js';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth.js';
import { buildSystemInstruction } from '../services/persona.js';

export const chatRouter = Router();

const CANDIDATE_MODELS = [
  'gemini-3-flash-preview',
  'gemini-3.5-flash',
  'gemini-3.8-flash',
  'gemini-flash-latest',
  'gemini-3.1-flash-lite',
  'gemini-3.6-flash',
];

const getGeminiClient = () => {
  const apiKey =
    process.env.GEMINI_API_KEY ||
    'AQ.Ab8RN6JEvJkxzIfCgO7oXcGbb98Sdjys1i1p_KJJOUqrRDi26g';
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

// 1. GET /api/chat/history - Retrieve currently logged-in user's private chat history
chatRouter.get(
  '/history',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response): Promise<any> => {
    try {
      const userId = req.user!.id;
      const history = await getUserChatHistory(userId);

      return res.json({
        history: history.map((msg) => ({
          id: String(msg.id),
          role: msg.role === 'model' || msg.role === 'assistant' ? 'model' : 'user',
          content: msg.message,
          timestamp: new Date(msg.created_at).getTime(),
        })),
      });
    } catch (error: any) {
      console.error('[Chat History Error]:', error);
      return res.status(500).json({
        error: 'Failed to retrieve chat history.',
      });
    }
  }
);

// 2. DELETE /api/chat/history - Clear currently logged-in user's chat history
chatRouter.delete(
  '/history',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response): Promise<any> => {
    try {
      const userId = req.user!.id;
      await clearUserChatHistory(userId);
      return res.json({ message: 'Chat history cleared successfully.' });
    } catch (error: any) {
      console.error('[Clear Chat History Error]:', error);
      return res.status(500).json({ error: 'Failed to clear chat history.' });
    }
  }
);

// 3. POST /api/chat - Send message, get response, and persist both under user's private history
chatRouter.post(
  '/',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response): Promise<any> => {
    try {
      const userId = req.user!.id;
      const { message, mode = 'Sela Fast', languagePreference = 'auto' } = req.body;

      if (!message || typeof message !== 'string' || message.trim().length === 0) {
        return res.status(400).json({ error: 'Message text is required.' });
      }

      const trimmedMessage = message.trim();

      // 1. Save user's message in PostgreSQL
      const userMsgRecord = await saveChatMessage({
        userId,
        role: 'user',
        message: trimmedMessage,
      });

      // 2. Load recent conversation history for context
      const existingHistory = await getUserChatHistory(userId, 8);
      const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

      for (const item of existingHistory) {
        contents.push({
          role: item.role === 'model' || item.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: item.message }],
        });
      }

      let currentPrompt = trimmedMessage;
      if (languagePreference && languagePreference !== 'auto') {
        currentPrompt += `\n[User requested language: ${languagePreference}]`;
      }

      // If the latest message wasn't in history yet
      if (!contents.some((c) => c.parts[0]?.text === trimmedMessage)) {
        contents.push({
          role: 'user',
          parts: [{ text: currentPrompt }],
        });
      }

      const ai = getGeminiClient();
      const systemInstruction = buildSystemInstruction(mode, req.user);
      let answer = '';
      let lastError: any = null;

      for (const modelName of CANDIDATE_MODELS) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents,
            config: {
              systemInstruction,
              temperature: 0.6,
            },
          });

          if (response && response.text) {
            answer = response.text;
            break;
          }
        } catch (modelErr: any) {
          lastError = modelErr;
          continue;
        }
      }

      if (!answer) {
        answer =
          'I received your message, but the AI service is currently busy. Please try asking again in a few moments.';
      }

      // 3. Save AI response in PostgreSQL
      const aiMsgRecord = await saveChatMessage({
        userId,
        role: 'model',
        message: answer,
      });

      return res.json({
        userMessage: {
          id: String(userMsgRecord.id),
          role: 'user',
          content: userMsgRecord.message,
          timestamp: new Date(userMsgRecord.created_at).getTime(),
        },
        aiMessage: {
          id: String(aiMsgRecord.id),
          role: 'model',
          content: aiMsgRecord.message,
          timestamp: new Date(aiMsgRecord.created_at).getTime(),
        },
      });
    } catch (error: any) {
      console.error('[Chat Send Error]:', error);
      return res.status(500).json({
        error: 'An error occurred while generating a response.',
      });
    }
  }
);
