import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Check, Copy } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export const MarkdownRenderer: React.FC<MarkdownRendererProps> = ({ content }) => {
  const [copiedCodeBlockIndex, setCopiedCodeBlockIndex] = useState<number | null>(null);

  const handleCopyCode = (codeText: string, index: number) => {
    navigator.clipboard.writeText(codeText);
    setCopiedCodeBlockIndex(index);
    setTimeout(() => {
      setCopiedCodeBlockIndex(null);
    }, 2000);
  };

  let codeBlockCounter = 0;

  return (
    <div className="text-white leading-relaxed text-[14.5px] sm:text-[15.5px] space-y-3 font-normal selection:bg-cyan-500/30 break-words max-w-full overflow-hidden">
      <ReactMarkdown
        components={{
          h1: ({ children }) => (
            <h1 className="text-lg sm:text-2xl font-bold text-white mt-4 sm:mt-5 mb-2 pb-1 border-b border-white/15 break-words">
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-base sm:text-xl font-bold text-white mt-3.5 sm:mt-4 mb-2 break-words">
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-sm sm:text-lg font-semibold text-white mt-3 mb-1.5 break-words">
              {children}
            </h3>
          ),
          p: ({ children }) => (
            <p className="mb-3 leading-6 sm:leading-7 text-[#f1f5f9] last:mb-0 break-words font-normal">
              {children}
            </p>
          ),
          ul: ({ children }) => (
            <ul className="list-disc list-outside pl-4 sm:pl-5 my-2 sm:my-2.5 space-y-1 sm:space-y-1.5 text-[#e2e8f0] break-words">
              {children}
            </ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal list-outside pl-4 sm:pl-5 my-2 sm:my-2.5 space-y-1 sm:space-y-1.5 text-[#e2e8f0] break-words">
              {children}
            </ol>
          ),
          li: ({ children }) => (
            <li className="leading-relaxed pl-1 text-[#e2e8f0] break-words">{children}</li>
          ),
          strong: ({ children }) => (
            <strong className="font-semibold text-white">{children}</strong>
          ),
          em: ({ children }) => (
            <em className="italic text-slate-100">{children}</em>
          ),
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-cyan-400 bg-white/[0.07] backdrop-blur-xs pl-3.5 sm:pl-4 py-2 my-3 rounded-r-lg text-slate-100 italic break-words">
              {children}
            </blockquote>
          ),
          code: ({ className, children, ...props }) => {
            const isInline = !className && typeof children === 'string' && !children.includes('\n');
            const codeString = String(children).replace(/\n$/, '');

            if (isInline) {
              return (
                <code
                  className="px-1.5 py-0.5 mx-0.5 rounded-md bg-white/15 text-emerald-300 font-mono text-[12px] sm:text-[13px] font-medium border border-white/20 break-all"
                  {...props}
                >
                  {children}
                </code>
              );
            }

            const currentIdx = codeBlockCounter++;
            const matchLang = /language-(\w+)/.exec(className || '');
            const language = matchLang ? matchLang[1] : '';

            return (
              <div className="relative my-3 rounded-xl overflow-hidden border border-white/20 bg-[#071320] text-slate-100 shadow-lg max-w-full">
                <div className="flex items-center justify-between px-3 sm:px-3.5 py-1.5 bg-[#0b1c2f] text-xs font-mono text-slate-300 border-b border-white/10">
                  <span className="text-[11px] sm:text-xs text-cyan-300">{language || 'code'}</span>
                  <button
                    id={`copy-code-btn-${currentIdx}`}
                    type="button"
                    onClick={() => handleCopyCode(codeString, currentIdx)}
                    className="flex items-center gap-1.5 px-2 py-0.5 rounded text-slate-300 hover:text-white hover:bg-white/10 transition-colors text-[11px] sm:text-xs cursor-pointer"
                    title="Copy code"
                  >
                    {copiedCodeBlockIndex === currentIdx ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400 font-medium">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-3 sm:p-4 overflow-x-auto text-[12px] sm:text-sm font-mono leading-relaxed text-[#f8fafc] max-w-full">
                  <code>{children}</code>
                </pre>
              </div>
            );
          },
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
};
