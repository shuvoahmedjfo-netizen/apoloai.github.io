import React from 'react';
import { X, Wrench, Globe, Calculator, Code2, Search, FileSearch, Check } from 'lucide-react';

interface ToolsModalProps {
  isOpen: boolean;
  activeTools: string[];
  onToggleTool: (toolId: string) => void;
  onClose: () => void;
}

const AVAILABLE_TOOLS = [
  {
    id: 'web-search',
    name: 'Live Web Grounding',
    desc: 'Fetch current web results and verified citations for real-time questions.',
    icon: Globe,
  },
  {
    id: 'code-eval',
    name: 'Python / Code Sandbox',
    desc: 'Execute calculations, data structures, and algorithms cleanly.',
    icon: Code2,
  },
  {
    id: 'doc-search',
    name: 'Document Vector Search',
    desc: 'Query uploaded workspace files using semantic similarity.',
    icon: FileSearch,
  },
  {
    id: 'calculator',
    name: 'Math & Unit Engine',
    desc: 'High-precision numerical computations and dimensional analysis.',
    icon: Calculator,
  },
];

export const ToolsModal: React.FC<ToolsModalProps> = ({
  isOpen,
  activeTools,
  onToggleTool,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#181a20] border border-[#2c2f38] text-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#282a33]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#242731] flex items-center justify-center text-zinc-300">
              <Wrench className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Agent Tools & Skills</h2>
              <p className="text-xs text-zinc-400">Select capabilities available to the assistant</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#252832] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of tools */}
        <div className="p-6 space-y-3">
          {AVAILABLE_TOOLS.map((tool) => {
            const isEnabled = activeTools.includes(tool.id);
            const Icon = tool.icon;
            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => onToggleTool(tool.id)}
                className={`w-full flex items-start justify-between p-3.5 rounded-xl border text-left transition-all ${
                  isEnabled
                    ? 'bg-[#212530] border-zinc-400 text-white'
                    : 'bg-[#1e2027] border-[#2c2f38] text-zinc-300 hover:bg-[#22242c]'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${isEnabled ? 'bg-white text-black' : 'bg-[#292c36] text-zinc-300'}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-white">{tool.name}</h3>
                    <p className="text-xs text-zinc-400 mt-0.5">{tool.desc}</p>
                  </div>
                </div>
                <div className="ml-3 shrink-0">
                  <div
                    className={`w-5 h-5 rounded-md flex items-center justify-center border transition-colors ${
                      isEnabled ? 'bg-white border-white text-black' : 'border-[#3f4350]'
                    }`}
                  >
                    {isEnabled && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-4 border-t border-[#282a33] bg-[#16171d]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-white text-black rounded-lg hover:bg-zinc-200 transition-colors"
          >
            Apply
          </button>
        </div>
      </div>
    </div>
  );
};
