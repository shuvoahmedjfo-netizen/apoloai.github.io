import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

export const AnythingLLMLogo: React.FC<LogoProps> = ({ className = 'w-8 h-8', size }) => {
  const style = size ? { width: size, height: size } : undefined;
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={style}
    >
      {/* Outer circle ring matching s.PNG */}
      <circle
        cx="16"
        cy="16"
        r="14.2"
        stroke="currentColor"
        strokeWidth="1.7"
      />
      {/* 8-tooth gear path */}
      <path
        d="M14.6 5.5H17.4L17.9 7.8C18.6 8.0 19.3 8.3 19.9 8.7L21.9 7.5L23.9 9.5L22.7 11.5C23.1 12.1 23.4 12.8 23.6 13.5L25.9 14.0V16.8L23.6 17.3C23.4 18.0 23.1 18.7 22.7 19.3L23.9 21.3L21.9 23.3L19.9 22.1C19.3 22.5 18.6 22.8 17.9 23.0L17.4 25.3H14.6L14.1 23.0C13.4 22.8 12.7 22.5 12.1 22.1L10.1 23.3L8.1 21.3L9.3 19.3C8.9 18.7 8.6 18.0 8.4 17.3L6.1 16.8V14.0L8.4 13.5C8.6 12.8 8.9 12.1 9.3 11.5L8.1 9.5L10.1 7.5L12.1 8.7C12.7 8.3 13.4 8.0 14.1 7.8L14.6 5.5Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Inner circle */}
      <circle
        cx="16"
        cy="15.4"
        r="3.8"
        stroke="currentColor"
        strokeWidth="1.6"
      />
    </svg>
  );
};
