import React, { useState } from 'react';
import { Copy, Check, RotateCw, Volume2, VolumeX, Sparkles, User, AlertCircle } from 'lucide-react';
import { Message } from '../types';
import { MarkdownRenderer } from './MarkdownRenderer';
import { detectLanguageFromText } from '../utils/language';

interface MessageItemProps {
  message: Message;
  isLast: boolean;
  isLoading: boolean;
  onRegenerate?: () => void;
  onRetry?: () => void;
}

export const MessageItem: React.FC<MessageItemProps> = ({
  message,
  isLast,
  isLoading,
  onRegenerate,
  onRetry,
}) => {
  const [copied, setCopied] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const isUser = message.role === 'user';
  const langInfo = detectLanguageFromText(message.content);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }

    window.speechSynthesis.cancel();
    // Strip markdown formatting for cleaner speech synthesis
    const cleanText = message.content
      .replace(/```[\s\S]*?```/g, 'Code block omitted.')
      .replace(/[#*_`]/g, '');

    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (langInfo.code && langInfo.code !== 'auto') {
      utterance.lang = langInfo.code;
    }

    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);

    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  if (isUser) {
    return (
      <div className="flex flex-col items-end mb-6 group">
        <div className="flex items-center gap-2 mb-1 text-xs text-slate-400">
          <span className="font-medium text-slate-500">You</span>
          {langInfo.code !== 'auto' && (
            <span className="text-[10px] px-1.5 py-0.2 bg-slate-100 rounded text-slate-500">
              {langInfo.nativeName}
            </span>
          )}
        </div>
        <div className="max-w-[92%] sm:max-w-[85%] bg-slate-900 text-white px-4 py-3 sm:px-5 sm:py-3.5 rounded-2xl rounded-tr-xs shadow-xs text-sm sm:text-base leading-relaxed">
          <p className="whitespace-pre-wrap break-words">{message.content}</p>
        </div>
      </div>
    );
  }

  // Model / AI Answer
  return (
    <div className="flex flex-col items-start mb-8 group">
      {/* AI Label & Language pill */}
      <div className="flex items-center gap-2 mb-2 text-xs text-slate-400">
        <div className="w-5 h-5 rounded-md bg-indigo-600 flex items-center justify-center text-white">
          <Sparkles className="w-3 h-3 text-white" />
        </div>
        <span className="font-semibold text-slate-700">Askly</span>
        <span className="text-[10px] px-1.5 py-0.5 bg-indigo-50 border border-indigo-100 rounded-md text-indigo-700 font-medium">
          {langInfo.nativeName}
        </span>
      </div>

      {/* Answer Body */}
      <div className="w-full bg-white border border-slate-200/80 rounded-2xl p-4 sm:p-6 shadow-xs transition-all">
        {message.isError ? (
          <div className="flex items-start gap-3 text-rose-700 bg-rose-50/70 p-4 rounded-xl border border-rose-200">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-rose-500" />
            <div className="space-y-2">
              <p className="text-sm font-medium">{message.content}</p>
              {onRetry && (
                <button
                  id="retry-question-btn"
                  type="button"
                  onClick={onRetry}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-rose-600 text-white hover:bg-rose-700 transition-colors shadow-2xs active:scale-95 cursor-pointer"
                >
                  <RotateCw className="w-3 h-3" />
                  <span>Retry Question</span>
                </button>
              )}
            </div>
          </div>
        ) : (
          <MarkdownRenderer content={message.content} />
        )}

        {/* Action Toolbar */}
        {!message.isError && (
          <div className="flex items-center justify-between pt-4 mt-4 border-t border-slate-100 text-slate-400 text-xs">
            <div className="flex items-center gap-1 sm:gap-2">
              {/* Copy Answer Button */}
              <button
                id={`copy-answer-btn-${message.id}`}
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-600 hover:text-slate-900 transition-colors active:scale-95 cursor-pointer"
                title="Copy answer"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600 font-medium">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>

              {/* Text-to-speech Read Aloud */}
              {'speechSynthesis' in window && (
                <button
                  type="button"
                  onClick={handleSpeak}
                  className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg transition-colors active:scale-95 cursor-pointer ${
                    isPlayingAudio
                      ? 'bg-indigo-50 text-indigo-700 font-medium'
                      : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900'
                  }`}
                  title={isPlayingAudio ? 'Stop reading' : 'Read aloud'}
                >
                  {isPlayingAudio ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Stop</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Listen</span>
                    </>
                  )}
                </button>
              )}

              {/* Regenerate Answer Button (for latest AI response) */}
              {isLast && onRegenerate && (
                <button
                  id="regenerate-answer-btn"
                  type="button"
                  onClick={onRegenerate}
                  disabled={isLoading}
                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 text-slate-600 hover:text-slate-900 transition-colors active:scale-95 disabled:opacity-50 cursor-pointer"
                  title="Regenerate this answer"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>Regenerate</span>
                </button>
              )}
            </div>

            <span className="text-[11px] text-slate-400">
              {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
