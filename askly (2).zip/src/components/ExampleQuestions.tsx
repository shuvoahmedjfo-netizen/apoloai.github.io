import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface ExampleQuestionsProps {
  onSelectQuestion: (question: string) => void;
}

const PRIMARY_EXAMPLES = [
  {
    text: 'What is artificial intelligence?',
    category: 'Technology',
    lang: 'English',
  },
  {
    text: 'বাংলাদেশের স্বাধীনতা দিবস কবে?',
    category: 'ইতিহাস',
    lang: 'বাংলা',
  },
  {
    text: 'How does the Internet work?',
    category: 'Science',
    lang: 'English',
  },
  {
    text: 'Explain photosynthesis simply.',
    category: 'Biology',
    lang: 'English',
  },
  {
    text: 'भारत की राजधानी क्या है?',
    category: 'सामान्य ज्ञान',
    lang: 'हिन्दी',
  },
  {
    text: '¿Cómo funciona la memoria humana?',
    category: 'Ciencia',
    lang: 'Español',
  },
];

export const ExampleQuestions: React.FC<ExampleQuestionsProps> = ({ onSelectQuestion }) => {
  return (
    <div className="w-full mt-6">
      <div className="flex items-center justify-between mb-3 px-1">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Try asking
        </span>
        <span className="text-xs text-slate-400">
          Supports any language automatically
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {PRIMARY_EXAMPLES.map((example, idx) => (
          <button
            key={idx}
            id={`example-question-${idx}`}
            type="button"
            onClick={() => onSelectQuestion(example.text)}
            className="group flex items-start justify-between p-3.5 bg-white hover:bg-slate-50/80 border border-slate-200/80 hover:border-indigo-300 rounded-xl text-left transition-all duration-150 shadow-2xs hover:shadow-xs active:scale-99 cursor-pointer"
          >
            <div className="pr-3">
              <p className="text-sm font-medium text-slate-800 group-hover:text-indigo-900 transition-colors">
                {example.text}
              </p>
              <div className="flex items-center gap-1.5 mt-1.5">
                <span className="text-[11px] font-medium text-indigo-600 bg-indigo-50/80 px-1.5 py-0.5 rounded">
                  {example.lang}
                </span>
                <span className="text-[11px] text-slate-400">
                  {example.category}
                </span>
              </div>
            </div>
            <ArrowUpRight className="w-4 h-4 text-slate-300 group-hover:text-indigo-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all shrink-0 mt-0.5" />
          </button>
        ))}
      </div>
    </div>
  );
};
