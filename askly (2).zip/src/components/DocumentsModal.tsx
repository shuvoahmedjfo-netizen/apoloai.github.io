import React, { useState, useRef } from 'react';
import { X, Upload, FileText, Trash2, CheckCircle2, HardDrive, AlertCircle } from 'lucide-react';
import { WorkspaceDocument } from '../types';

interface DocumentsModalProps {
  isOpen: boolean;
  documents: WorkspaceDocument[];
  onClose: () => void;
  onAddDocument: (doc: WorkspaceDocument) => void;
  onRemoveDocument: (id: string) => void;
}

export const DocumentsModal: React.FC<DocumentsModalProps> = ({
  isOpen,
  documents,
  onClose,
  onAddDocument,
  onRemoveDocument,
}) => {
  const [dragOver, setDragOver] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleProcessFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const newDoc: WorkspaceDocument = {
        id: 'doc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        name: file.name,
        size: (file.size / 1024).toFixed(1) + ' KB',
        type: file.type || file.name.split('.').pop() || 'document',
        content: text || '',
        uploadedAt: Date.now(),
      };
      onAddDocument(newDoc);
      setStatusMessage(`Added "${file.name}" to workspace context.`);
      setTimeout(() => setStatusMessage(null), 3000);
    };
    reader.onerror = () => {
      setStatusMessage(`Failed to read file ${file.name}`);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      Array.from(e.dataTransfer.files).forEach(handleProcessFile);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      Array.from(e.target.files).forEach(handleProcessFile);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#181a20] border border-[#2c2f38] text-white rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#282a33]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#242731] flex items-center justify-center text-zinc-300">
              <HardDrive className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Workspace Documents</h2>
              <p className="text-xs text-zinc-400">Embed files into workspace context for chat grounding</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#252832] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {statusMessage && (
            <div className="flex items-center gap-2 p-3 bg-zinc-800 border border-zinc-700 rounded-xl text-xs text-zinc-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* Upload Dropzone */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-colors ${
              dragOver
                ? 'border-white bg-[#222530]'
                : 'border-[#2f333f] bg-[#1d1f27] hover:border-zinc-500 hover:bg-[#20222b]'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              onChange={handleFileInput}
              className="hidden"
              accept=".txt,.md,.json,.csv,.js,.ts,.py,.html,.css"
            />
            <div className="w-10 h-10 mx-auto rounded-full bg-[#272a34] flex items-center justify-center text-zinc-300 mb-3">
              <Upload className="w-5 h-5" />
            </div>
            <p className="text-sm font-medium text-white mb-1">Click to upload or drag & drop</p>
            <p className="text-xs text-zinc-400">Supported: TXT, Markdown, JSON, Code, CSV (Text files)</p>
          </div>

          {/* Document list */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-zinc-400">
                Active Documents ({documents.length})
              </span>
            </div>

            {documents.length === 0 ? (
              <div className="p-4 rounded-xl bg-[#1d1f26] border border-[#2a2d36] text-center text-xs text-zinc-400">
                No documents embedded in this workspace yet. Upload files to enhance AI answers with custom knowledge.
              </div>
            ) : (
              <div className="space-y-2">
                {documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between p-3 bg-[#1e2129] border border-[#2a2d37] rounded-xl group hover:border-[#383d4c] transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-[#262935] flex items-center justify-center text-zinc-400 shrink-0">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-white truncate">{doc.name}</p>
                        <p className="text-[11px] text-zinc-400 font-mono">{doc.size}</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onRemoveDocument(doc.id)}
                      className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-[#2b2e3b] transition-colors"
                      title="Remove document"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-4 border-t border-[#282a33] bg-[#16171d]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium bg-white text-black rounded-lg hover:bg-zinc-200 transition-colors font-semibold"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
