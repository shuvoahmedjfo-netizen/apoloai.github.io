import React from 'react';
import { Sparkles, Plus, Globe } from 'lucide-react';
import { SupportedLanguage } from '../types';

interface HeaderProps {
  onNewChat: () => void;
  hasMessages: boolean;
  selectedLanguage: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
}

const LANGUAGES: Array<{ code: SupportedLanguage; label: string; flag?: string }> = [
  { code: 'auto', label: 'Auto (Same as question)' },
  { code: 'bn', label: 'বাংলা (Bengali)' },
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'हिन्दी (Hindi)' },
  { code: 'es', label: 'Español (Spanish)' },
  { code: 'ar', label: 'العربية (Arabic)' },
  { code: 'fr', label: 'Français (French)' },
  { code: 'de', label: 'Deutsch (German)' },
  { code: 'ur', label: 'اردو (Urdu)' },
];

export const Header: React.FC<HeaderProps> = ({
  onNewChat,
  hasMessages,
  selectedLanguage,
  onLanguageChange,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 transition-all">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white shadow-xs">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-lg sm:text-xl tracking-tight text-slate-900">
                Askly
              </span>
              <span className="text-[11px] font-medium px-1.5 py-0.2 text-indigo-600 bg-indigo-50 border border-indigo-100 rounded-md">
                AI Q&A
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              Ask anything. Get a clear answer.
            </p>
          </div>
        </div>

        {/* Top actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Language selector */}
          <div className="relative flex items-center">
            <Globe className="w-4 h-4 text-slate-400 absolute left-2.5 pointer-events-none" />
            <select
              id="language-preference-select"
              value={selectedLanguage}
              onChange={(e) => onLanguageChange(e.target.value as SupportedLanguage)}
              className="pl-8 pr-7 py-1.5 text-xs font-medium text-slate-700 bg-slate-100/90 hover:bg-slate-200/70 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer appearance-none transition-colors"
              title="Select reply language or keep auto-detect"
            >
              {LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.label}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute right-2 text-slate-400 text-[10px]">
              ▼
            </div>
          </div>

          {/* New Chat Button */}
          {hasMessages && (
            <button
              id="new-chat-header-btn"
              type="button"
              onClick={onNewChat}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl shadow-2xs hover:shadow-xs transition-all active:scale-97 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-indigo-600" />
              <span>New Chat</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
