import React, { useState, useEffect, useRef } from 'react';
import { ArrowUp, Mic, MicOff } from 'lucide-react';

interface QuestionInputProps {
  onSend: (question: string) => void;
  isLoading: boolean;
  initialValue?: string;
  isFloatingBottom?: boolean;
}

export const QuestionInput: React.FC<QuestionInputProps> = ({
  onSend,
  isLoading,
  initialValue = '',
  isFloatingBottom = false,
}) => {
  const [value, setValue] = useState(initialValue);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const recognitionRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (initialValue) {
      setValue(initialValue);
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }
  }, [initialValue]);

  // Speech recognition setup
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      setSpeechSupported(true);
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = ''; // Let browser auto-detect or use user default

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setValue((prev) => (prev ? `${prev.trim()} ${transcript}` : transcript));
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setErrorMessage('Microphone access was denied. Please allow microphone permissions.');
        } else if (event.error !== 'no-speech') {
          setErrorMessage('Could not capture audio. Please try again or type your question.');
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollHeight = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = `${Math.min(scrollHeight, 180)}px`;
    }
  }, [value]);

  const toggleListening = () => {
    if (!speechSupported) {
      setErrorMessage('Speech recognition is not supported in this browser.');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      setErrorMessage(null);
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (err) {
        console.error('Failed to start speech recognition:', err);
        setIsListening(false);
      }
    }
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const trimmed = value.trim();
    if (!trimmed) {
      setErrorMessage('Please type a question before sending.');
      if (textareaRef.current) textareaRef.current.focus();
      return;
    }

    setErrorMessage(null);
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    }

    onSend(trimmed);
    setValue('');

    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className={`w-full ${isFloatingBottom ? 'max-w-3xl mx-auto' : ''}`}>
      <form
        onSubmit={handleSubmit}
        className={`relative bg-white rounded-2xl border transition-all duration-200 ${
          errorMessage
            ? 'border-rose-300 ring-2 ring-rose-100'
            : isListening
            ? 'border-red-400 ring-4 ring-red-50'
            : 'border-slate-200/90 shadow-sm hover:border-slate-300 focus-within:border-indigo-500 focus-within:ring-4 focus-within:ring-indigo-500/10'
        }`}
      >
        <div className="p-3 sm:p-4">
          <textarea
            id="question-input-textarea"
            ref={textareaRef}
            rows={isFloatingBottom ? 1 : 2}
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              if (errorMessage) setErrorMessage(null);
            }}
            onKeyDown={handleKeyDown}
            placeholder={isListening ? 'Listening... Speak your question now' : 'Type your question here...'}
            disabled={isLoading}
            className="w-full bg-transparent resize-none outline-none text-slate-800 placeholder-slate-400 text-sm sm:text-base leading-relaxed max-h-48 overflow-y-auto"
          />

          <div className="flex items-center justify-between pt-2 border-t border-slate-100 mt-1">
            <div className="flex items-center gap-2">
              {/* Mic button */}
              {speechSupported && (
                <button
                  id="voice-input-btn"
                  type="button"
                  onClick={toggleListening}
                  disabled={isLoading}
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-medium transition-colors ${
                    isListening
                      ? 'bg-rose-50 text-rose-600 border border-rose-200 animate-pulse'
                      : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
                  }`}
                  title={isListening ? 'Stop listening' : 'Speak your question'}
                >
                  {isListening ? (
                    <>
                      <MicOff className="w-3.5 h-3.5 text-rose-500" />
                      <span className="font-semibold">Listening...</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5 text-slate-500" />
                      <span className="hidden sm:inline">Voice</span>
                    </>
                  )}
                </button>
              )}

              <span className="text-[11px] text-slate-400 hidden sm:inline">
                Enter to send, Shift+Enter for new line
              </span>
            </div>

            <div className="flex items-center gap-2">
              {/* Send button with arrow icon */}
              <button
                id="send-question-btn"
                type="submit"
                disabled={isLoading || !value.trim()}
                className={`flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-xl transition-all duration-150 active:scale-95 ${
                  value.trim() && !isLoading
                    ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs cursor-pointer'
                    : 'bg-slate-100 text-slate-300 cursor-not-allowed'
                }`}
                title="Send question"
              >
                <ArrowUp className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
              </button>
            </div>
          </div>
        </div>
      </form>

      {/* Helpful validation or mic message */}
      {errorMessage && (
        <p className="mt-2 text-xs text-rose-500 font-medium px-2 flex items-center gap-1 animate-fadeIn">
          <span>•</span> {errorMessage}
        </p>
      )}
    </div>
  );
};
