import React from 'react';
import { X, MessageSquare, ExternalLink, Heart, Github, Send } from 'lucide-react';

interface CommunityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CommunityModal: React.FC<CommunityModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#181a20] border border-[#2c2f38] text-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#282a33]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#242731] flex items-center justify-center text-zinc-300">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Community & Support</h2>
              <p className="text-xs text-zinc-400">Join the builder community & provide feedback</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#252832] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div className="p-4 bg-[#1f2129] border border-[#2c2f38] rounded-xl text-center">
            <div className="w-12 h-12 rounded-full bg-[#272a34] mx-auto flex items-center justify-center text-indigo-400 mb-2.5">
              <Heart className="w-6 h-6 fill-indigo-400/20" />
            </div>
            <h3 className="text-sm font-semibold text-white">AnythingLLM Workspace</h3>
            <p className="text-xs text-zinc-400 mt-1">
              Private, single-tenant AI workspace with full document RAG, multilingual support, and local model orchestration.
            </p>
          </div>

          <div className="space-y-2">
            <a
              href="https://github.com"
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between p-3 bg-[#1d1f27] border border-[#2b2d37] rounded-xl text-zinc-200 hover:text-white hover:bg-[#22242d] transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <Github className="w-4 h-4 text-zinc-400" />
                <span className="text-xs font-medium">GitHub Repository</span>
              </div>
              <ExternalLink className="w-3.5 h-3.5 text-zinc-500" />
            </a>

            <a
              href="https://discord.com"
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-between p-3 bg-[#1d1f27] border border-[#2b2d37] rounded-xl text-zinc-200 hover:text-white hover:bg-[#22242d] transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <MessageSquare className="w-4 h-4 text-indigo-400" />
                <span className="text-xs font-medium">Discord Community</span>
              </div>
              <ExternalLink className="w-3.5 h-3.5 text-zinc-500" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-4 border-t border-[#282a33] bg-[#16171d]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-white text-black rounded-lg hover:bg-zinc-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
