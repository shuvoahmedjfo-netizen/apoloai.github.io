import React from 'react';
import { X, BookOpen, Sparkles, Terminal, FileCode, MessageSquareText } from 'lucide-react';

interface LibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPrompt: (promptText: string) => void;
}

const TEMPLATES = [
  {
    title: 'Code Refactoring & Types',
    category: 'Engineering',
    prompt: 'Refactor this TypeScript function for optimal performance, strict typing, and immutability:\n\n```ts\n\n```',
  },
  {
    title: 'Executive Summary',
    category: 'Analysis',
    prompt: 'Provide a high-level executive briefing with 3 key takeaways and actionable next steps for the following document:\n\n',
  },
  {
    title: 'Multilingual Translator (Bangla & English)',
    category: 'Language',
    prompt: 'Translate the following passage into fluent, natural Bengali and provide a vocabulary breakdown of key phrases:\n\n',
  },
  {
    title: 'System Architecture Critique',
    category: 'Architecture',
    prompt: 'Analyze this distributed system design for latency bottlenecks, single points of failure, and security risks:\n\n',
  },
];

export const LibraryModal: React.FC<LibraryModalProps> = ({ isOpen, onClose, onSelectPrompt }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#181a20] border border-[#2c2f38] text-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#282a33]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#242731] flex items-center justify-center text-zinc-300">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Prompt Library & Guides</h2>
              <p className="text-xs text-zinc-400">Curated prompts and workflow templates</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#252832] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-3 overflow-y-auto flex-1">
          {TEMPLATES.map((item, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-[#1d1f27] border border-[#2a2d36] rounded-xl hover:border-zinc-500 transition-colors"
            >
              <div className="flex items-center justify-between mb-1.5">
                <h3 className="text-sm font-medium text-white">{item.title}</h3>
                <span className="text-[11px] px-2 py-0.5 rounded bg-[#282a34] text-zinc-400 font-mono">
                  {item.category}
                </span>
              </div>
              <p className="text-xs text-zinc-400 font-mono line-clamp-2 mb-3 bg-[#17181f] p-2 rounded-lg border border-[#252731]">
                {item.prompt}
              </p>
              <button
                type="button"
                onClick={() => {
                  onSelectPrompt(item.prompt);
                  onClose();
                }}
                className="w-full py-1.5 px-3 bg-[#262832] hover:bg-white hover:text-black rounded-lg text-xs font-medium text-zinc-200 transition-colors text-center"
              >
                Use Template
              </button>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-4 border-t border-[#282a33] bg-[#16171d]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-white text-black rounded-lg hover:bg-zinc-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
