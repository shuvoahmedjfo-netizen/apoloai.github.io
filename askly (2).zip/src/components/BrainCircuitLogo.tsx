import React from 'react';

interface BrainCircuitLogoProps {
  className?: string;
  size?: number;
}

/**
 * Line-art circuit brain matching Capture.PNG:
 * Symmetrical left and right hemispheres with electronic circuit traces and terminal nodes.
 */
export const BrainCircuitLogo: React.FC<BrainCircuitLogoProps> = ({
  className = 'w-7 h-7 text-black dark:text-white',
  size,
}) => {
  const style = size ? { width: size, height: size } : undefined;

  return (
    <svg
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={style}
    >
      {/* Central Divider Gap between Left (<=56) and Right (>=64) */}

      {/* LEFT HEMISPHERE */}
      {/* Outer Gyri / Lobes */}
      <path
        d="M 54 22 
           C 42 21 34 26 31 34 
           C 22 36 17 44 19 53 
           C 14 59 14 69 19 76 
           C 17 85 24 93 33 94 
           C 39 101 50 99 54 96"
        stroke="currentColor"
        strokeWidth="5.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Left Circuit Traces */}
      {/* Top Circuit Trace */}
      <path
        d="M 54 36 L 46 36 L 46 30"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="46" cy="27" r="3.2" fill="currentColor" />

      {/* Upper-Mid Diagonal Trace */}
      <path
        d="M 54 48 L 41 48 L 33 40"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="31" cy="38" r="3.2" fill="currentColor" />

      {/* Mid Horizontal Trace */}
      <path
        d="M 54 60 L 39 60"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="35" cy="60" r="3.2" fill="currentColor" />

      {/* Lower-Mid Diagonal Trace */}
      <path
        d="M 54 72 L 41 72 L 33 80"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="31" cy="82" r="3.2" fill="currentColor" />

      {/* Bottom Circuit Trace */}
      <path
        d="M 54 84 L 46 84 L 46 90"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="46" cy="93" r="3.2" fill="currentColor" />


      {/* RIGHT HEMISPHERE (Symmetrical) */}
      {/* Outer Gyri / Lobes */}
      <path
        d="M 66 22 
           C 78 21 86 26 89 34 
           C 98 36 103 44 101 53 
           C 106 59 106 69 101 76 
           C 103 85 96 93 87 94 
           C 81 101 70 99 66 96"
        stroke="currentColor"
        strokeWidth="5.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Right Circuit Traces */}
      {/* Top Circuit Trace */}
      <path
        d="M 66 36 L 74 36 L 74 30"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="74" cy="27" r="3.2" fill="currentColor" />

      {/* Upper-Mid Diagonal Trace */}
      <path
        d="M 66 48 L 79 48 L 87 40"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="89" cy="38" r="3.2" fill="currentColor" />

      {/* Mid Horizontal Trace */}
      <path
        d="M 66 60 L 81 60"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="85" cy="60" r="3.2" fill="currentColor" />

      {/* Lower-Mid Diagonal Trace */}
      <path
        d="M 66 72 L 79 72 L 87 80"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="89" cy="82" r="3.2" fill="currentColor" />

      {/* Bottom Circuit Trace */}
      <path
        d="M 66 84 L 74 84 L 74 90"
        stroke="currentColor"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="74" cy="93" r="3.2" fill="currentColor" />
    </svg>
  );
};
