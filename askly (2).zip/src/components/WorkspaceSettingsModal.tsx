import React, { useState } from 'react';
import { X, Sliders, Check, Sparkles, Cpu, ShieldAlert } from 'lucide-react';
import { Workspace } from '../types';

interface WorkspaceSettingsModalProps {
  isOpen: boolean;
  workspace: Workspace;
  onClose: () => void;
  onSave: (updated: Partial<Workspace>) => void;
}

const AVAILABLE_MODELS = [
  { id: 'Apolo 2.1', name: 'Apolo 2.1', provider: 'Apolo Core', desc: 'Conversational AI assistant with multilingual Bengali & English reasoning.' },
];

export const WorkspaceSettingsModal: React.FC<WorkspaceSettingsModalProps> = ({
  isOpen,
  workspace,
  onClose,
  onSave,
}) => {
  const [name, setName] = useState(workspace.name);
  const [model, setModel] = useState(workspace.model || 'Apolo 2.1');
  const [temperature, setTemperature] = useState(workspace.temperature ?? 0.7);
  const [systemPrompt, setSystemPrompt] = useState(
    workspace.systemPrompt || 'You are a helpful, direct, and concise AI assistant.'
  );

  if (!isOpen) return null;

  const handleSave = () => {
    onSave({
      name: name.trim() || workspace.name,
      model,
      temperature,
      systemPrompt,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-[#181a20] border border-[#2c2f38] text-white rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#282a33]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#242731] flex items-center justify-center text-zinc-300">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-white">Workspace Settings</h2>
              <p className="text-xs text-zinc-400">Configure parameters for {workspace.name}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#252832] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* Workspace Name */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              Workspace Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-[#20222a] border border-[#2d3039] rounded-xl text-sm text-white focus:outline-none focus:border-zinc-500 transition-colors"
              placeholder="e.g. My Workspace"
            />
          </div>

          {/* Model Selection */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              Chat Model
            </label>
            <div className="grid grid-cols-1 gap-2">
              {AVAILABLE_MODELS.map((item) => {
                const isSelected = model === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setModel(item.id)}
                    className={`flex items-start justify-between p-3 rounded-xl border text-left transition-all ${
                      isSelected
                        ? 'bg-[#222632] border-zinc-400 text-white'
                        : 'bg-[#1f2128] border-[#2c2f38] text-zinc-300 hover:bg-[#232630]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-white">{item.name}</span>
                        <span className="text-[11px] px-2 py-0.5 rounded bg-[#2b2e38] text-zinc-400 font-mono">
                          {item.provider}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-400 mt-1">{item.desc}</p>
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full bg-white text-black flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Temperature Slider */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-zinc-300">
                LLM Temperature: <span className="font-mono text-white">{temperature.toFixed(2)}</span>
              </label>
              <span className="text-[11px] text-zinc-400">
                {temperature < 0.4 ? 'Precise / Deterministic' : temperature > 0.8 ? 'Creative / Exploratory' : 'Balanced'}
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="w-full accent-white h-1.5 bg-[#2a2d36] rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* System Prompt */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">
              Workspace System Prompt (Instructions)
            </label>
            <textarea
              rows={4}
              value={systemPrompt}
              onChange={(e) => setSystemPrompt(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-[#20222a] border border-[#2d3039] rounded-xl text-sm text-white focus:outline-none focus:border-zinc-500 font-mono text-xs leading-relaxed resize-none transition-colors"
              placeholder="Provide system instructions for this workspace..."
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-[#282a33] bg-[#16171d]">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-zinc-400 hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-2 text-xs font-medium bg-white text-black rounded-lg hover:bg-zinc-200 transition-colors font-semibold"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};
