/**
 * Language detection heuristic helper
 */
export function detectLanguageFromText(text: string): { code: string; label: string; nativeName: string } {
  if (!text || text.trim() === '') {
    return { code: 'auto', label: 'Auto Detect', nativeName: 'Auto' };
  }

  // Bengali Unicode range: 0980-09FF
  if (/[\u0980-\u09FF]/.test(text)) {
    return { code: 'bn', label: 'Bengali', nativeName: 'বাংলা' };
  }

  // Devanagari / Hindi Unicode range: 0900-097F
  if (/[\u0900-\u097F]/.test(text)) {
    return { code: 'hi', label: 'Hindi', nativeName: 'हिन्दी' };
  }

  // Arabic / Urdu Unicode range: 0600-06FF, 0750-077F, 08A0-08FF
  if (/[\u0600-\u06FF\u0750-\u077F]/.test(text)) {
    return { code: 'ar', label: 'Arabic', nativeName: 'العربية' };
  }

  // Cyrillic / Russian: 0400-04FF
  if (/[\u0400-\u04FF]/.test(text)) {
    return { code: 'ru', label: 'Russian', nativeName: 'Русский' };
  }

  // Chinese: 4E00-9FFF
  if (/[\u4E00-\u9FFF]/.test(text)) {
    return { code: 'zh', label: 'Chinese', nativeName: '中文' };
  }

  // Japanese Hiragana/Katakana: 3040-309F, 30A0-30FF
  if (/[\u3040-\u309F\u30A0-\u30FF]/.test(text)) {
    return { code: 'ja', label: 'Japanese', nativeName: '日本語' };
  }

  // Korean Hangul: AC00-D7AF, 1100-11FF
  if (/[\uAC00-\uD7AF]/.test(text)) {
    return { code: 'ko', label: 'Korean', nativeName: '한국어' };
  }

  // Spanish characteristic words/letters
  if (/[áéíóúüñ¿¡]/i.test(text) || /\b(hola|que|cómo|por qué|cuál|dónde|gracias|es|los|las|una)\b/i.test(text)) {
    return { code: 'es', label: 'Spanish', nativeName: 'Español' };
  }

  // French characteristic words/letters
  if (/[àâçéèêëîïôûùüÿœæ]/i.test(text) || /\b(bonjour|pourquoi|comment|merci|avec|dans|pour|est)\b/i.test(text)) {
    return { code: 'fr', label: 'French', nativeName: 'Français' };
  }

  // German characteristic words/letters
  if (/[äöüß]/i.test(text) || /\b(hallo|warum|wie|danke|bitte|ist|und|nicht)\b/i.test(text)) {
    return { code: 'de', label: 'German', nativeName: 'Deutsch' };
  }

  // Default to English
  return { code: 'en', label: 'English', nativeName: 'English' };
}
