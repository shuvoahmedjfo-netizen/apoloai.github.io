/**
 * API URL helper for cross-platform compatibility (Web & Android Capacitor).
 * 
 * - In web browser: Uses relative URL ('/api/...').
 * - In Android Native: Routes to VITE_API_BASE_URL or production Cloud Run endpoint.
 */

export const getApiBaseUrl = (): string => {
  // Check if an explicit backend URL was specified at build time
  const envUrl = (import.meta as any).env?.VITE_API_BASE_URL;
  if (envUrl && typeof envUrl === 'string' && envUrl.trim().length > 0) {
    return envUrl.trim().replace(/\/$/, '');
  }

  // Detect Capacitor native platform
  if (typeof window !== 'undefined') {
    const isCapacitor = Boolean(
      (window as any).Capacitor?.isNativePlatform?.() ||
      window.location.protocol === 'capacitor:' ||
      (window.location.hostname === 'localhost' && !window.location.port)
    );

    if (isCapacitor) {
      // Connect to the deployed backend server
      return 'https://ais-dev-kpmkhpfnufj2vbdqv3eunb-78074898200.asia-southeast1.run.app';
    }
  }

  return '';
};

export const apiUrl = (endpoint: string): string => {
  const base = getApiBaseUrl();
  const path = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  return `${base}${path}`;
};
