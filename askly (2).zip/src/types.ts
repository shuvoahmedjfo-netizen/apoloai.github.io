export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: number;
  detectedLanguage?: string;
  isError?: boolean;
  modelUsed?: string;
  executionTime?: number; // e.g. 1.436
  tokensPerSecond?: number; // e.g. 6.96
  formattedTime?: string; // e.g. "Apr 2, 6:12 AM"
}

export interface ConversationHistoryItem {
  role: 'user' | 'model';
  content: string;
}

export interface ChatThread {
  id: string;
  name: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
}

export interface Workspace {
  id: string;
  name: string;
  threads: ChatThread[];
  activeThreadId: string;
  systemPrompt?: string;
  temperature?: number;
  model?: string;
  documents?: WorkspaceDocument[];
}

export interface WorkspaceDocument {
  id: string;
  name: string;
  size: string;
  type: string;
  content?: string;
  uploadedAt: number;
}

export type SupportedLanguage = 
  | 'auto'
  | 'bn' // Bengali
  | 'en' // English
  | 'hi' // Hindi
  | 'ar' // Arabic
  | 'es' // Spanish
  | 'fr' // French
  | 'de' // German
  | 'ur'; // Urdu
