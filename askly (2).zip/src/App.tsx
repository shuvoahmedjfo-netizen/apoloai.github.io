import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  Plus,
  GripVertical,
  Upload,
  SlidersHorizontal,
  Volume2,
  VolumeX,
  Mic,
  ArrowUp,
  Loader2,
  AtSign,
  History,
  MessageSquare,
  Trash2,
  Copy,
  Check,
  Edit2,
  X,
} from 'lucide-react';
import { AnythingLLMLogo } from './components/AnythingLLMLogo';
import { MarkdownRenderer } from './components/MarkdownRenderer';
import { WorkspaceSettingsModal } from './components/WorkspaceSettingsModal';
import { DocumentsModal } from './components/DocumentsModal';
import { ToolsModal } from './components/ToolsModal';
import { LibraryModal } from './components/LibraryModal';
import { CommunityModal } from './components/CommunityModal';
import { AuthModal } from './components/AuthModal';
import { SelaApiModal } from './components/SelaApiModal';
import { Message, Workspace, WorkspaceDocument } from './types';
import { apiUrl } from './utils/api';

const DEFAULT_WORKSPACE_ID = 'ws-default';
const DEFAULT_THREAD_ID = 'thread-default';

const formatTelemetryDate = (timestamp: number) => {
  const d = new Date(timestamp);
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const month = months[d.getMonth()];
  const day = d.getDate();
  let hours = d.getHours();
  const minutes = d.getMinutes().toString().padStart(2, '0');
  const ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12;
  return `${month} ${day}, ${hours}:${minutes} ${ampm}`;
};

const SMOOTH_SPRING = {
  type: 'spring' as const,
  stiffness: 300,
  damping: 30,
  mass: 0.8,
};

export default function App() {
  // Sidebar responsive state
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 1024;
    }
    return true;
  });

  const [isHistoryExpanded, setIsHistoryExpanded] = useState(true);

  // Workspaces state
  const [workspaces, setWorkspaces] = useState<Workspace[]>(() => {
    try {
      const saved = localStorage.getItem('sela_workspaces_v3');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return [
      {
        id: DEFAULT_WORKSPACE_ID,
        name: 'My Workspace',
        activeThreadId: DEFAULT_THREAD_ID,
        model: 'Apolo 2.1',
        temperature: 0.7,
        systemPrompt: 'You are a helpful, direct, and concise AI assistant.',
        documents: [],
        threads: [
          {
            id: DEFAULT_THREAD_ID,
            name: 'New Chat',
            messages: [],
            createdAt: Date.now(),
            updatedAt: Date.now(),
          },
        ],
      },
    ];
  });

  const [activeWorkspaceId, setActiveWorkspaceId] = useState(DEFAULT_WORKSPACE_ID);
  const [searchQuery, setSearchQuery] = useState('');
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editDraftText, setEditDraftText] = useState('');

  // Modals state
  const [isWorkspaceSettingsOpen, setIsWorkspaceSettingsOpen] = useState(false);
  const [isDocumentsModalOpen, setIsDocumentsModalOpen] = useState(false);
  const [isToolsModalOpen, setIsToolsModalOpen] = useState(false);
  const [isLibraryModalOpen, setIsLibraryModalOpen] = useState(false);
  const [isCommunityModalOpen, setIsCommunityModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isSelaApiModalOpen, setIsSelaApiModalOpen] = useState(false);

  // Active tools & user state
  const [activeTools, setActiveTools] = useState<string[]>(['web-search', 'doc-search']);
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);

  // Persist workspaces
  useEffect(() => {
    try {
      localStorage.setItem('sela_workspaces_v3', JSON.stringify(workspaces));
    } catch {
      // ignore
    }
  }, [workspaces]);

  // Active workspace & active thread helpers
  const currentWorkspace =
    workspaces.find((w) => w.id === activeWorkspaceId) || workspaces[0];

  const currentThread =
    currentWorkspace.threads.find((t) => t.id === currentWorkspace.activeThreadId) ||
    currentWorkspace.threads[0] || {
      id: DEFAULT_THREAD_ID,
      name: 'New Chat',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentThread.messages, isLoading]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  }, [inputText]);

  // Check auth status
  useEffect(() => {
    fetch(apiUrl('/api/auth/me'), { credentials: 'include' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data?.user) setCurrentUser(data.user);
      })
      .catch(() => {});
  }, []);

  // Workspace actions
  const handleUpdateWorkspace = (updated: Partial<Workspace>) => {
    setWorkspaces((prev) =>
      prev.map((w) => (w.id === currentWorkspace.id ? { ...w, ...updated } : w))
    );
  };

  const handleQuickNewChat = () => {
    const newThreadId = 'thread_' + Date.now();
    setWorkspaces((prev) =>
      prev.map((w) => {
        if (w.id === currentWorkspace.id) {
          return {
            ...w,
            threads: [
              {
                id: newThreadId,
                name: 'New Chat',
                messages: [],
                createdAt: Date.now(),
                updatedAt: Date.now(),
              },
              ...w.threads,
            ],
            activeThreadId: newThreadId,
          };
        }
        return w;
      })
    );
  };

  const handleSelectThread = (threadId: string) => {
    setWorkspaces((prev) =>
      prev.map((w) =>
        w.id === currentWorkspace.id ? { ...w, activeThreadId: threadId } : w
      )
    );
  };

  const handleDeleteThread = (e: React.MouseEvent, threadId: string) => {
    e.stopPropagation();
    setWorkspaces((prev) =>
      prev.map((w) => {
        if (w.id !== currentWorkspace.id) return w;
        const remaining = w.threads.filter((t) => t.id !== threadId);
        if (remaining.length === 0) {
          const fallbackId = 'thread_' + Date.now();
          return {
            ...w,
            threads: [
              {
                id: fallbackId,
                name: 'New Chat',
                messages: [],
                createdAt: Date.now(),
                updatedAt: Date.now(),
              },
            ],
            activeThreadId: fallbackId,
          };
        }
        const nextActive =
          w.activeThreadId === threadId ? remaining[0].id : w.activeThreadId;
        return {
          ...w,
          threads: remaining,
          activeThreadId: nextActive,
        };
      })
    );
  };

  const handleClearAllHistory = () => {
    const freshId = 'thread_' + Date.now();
    setWorkspaces((prev) =>
      prev.map((w) =>
        w.id === currentWorkspace.id
          ? {
              ...w,
              threads: [
                {
                  id: freshId,
                  name: 'New Chat',
                  messages: [],
                  createdAt: Date.now(),
                  updatedAt: Date.now(),
                },
              ],
              activeThreadId: freshId,
            }
          : w
      )
    );
  };

  // Document management
  const handleAddDocument = (doc: WorkspaceDocument) => {
    setWorkspaces((prev) =>
      prev.map((w) => {
        if (w.id === currentWorkspace.id) {
          return {
            ...w,
            documents: [...(w.documents || []), doc],
          };
        }
        return w;
      })
    );
  };

  const handleRemoveDocument = (docId: string) => {
    setWorkspaces((prev) =>
      prev.map((w) => {
        if (w.id === currentWorkspace.id) {
          return {
            ...w,
            documents: (w.documents || []).filter((d) => d.id !== docId),
          };
        }
        return w;
      })
    );
  };

  // Tools toggle
  const handleToggleTool = (toolId: string) => {
    setActiveTools((prev) =>
      prev.includes(toolId) ? prev.filter((id) => id !== toolId) : [...prev, toolId]
    );
  };

  // Text-To-Speech (Speaker icon)
  const handleSpeak = (messageId: string, text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    if (speakingMessageId === messageId) {
      window.speechSynthesis.cancel();
      setSpeakingMessageId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setSpeakingMessageId(null);
    utterance.onerror = () => setSpeakingMessageId(null);
    setSpeakingMessageId(messageId);
    window.speechSynthesis.speak(utterance);
  };

  // Microphone (Voice-to-text)
  const handleToggleMic = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText((prev) => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListening(false);
    }
  };

  // Submit message to AI
  const sendPromptWithHistory = async (promptText: string, baseMessages: Message[]) => {
    const trimmed = promptText.trim();
    if (!trimmed || isLoading) return;

    const userMessageTimestamp = Date.now();
    const userMessage: Message = {
      id: 'msg_' + userMessageTimestamp,
      role: 'user',
      content: trimmed,
      timestamp: userMessageTimestamp,
    };

    const updatedMessages = [...baseMessages, userMessage];
    const autoThreadTitle =
      baseMessages.length === 0
        ? trimmed.slice(0, 34) + (trimmed.length > 34 ? '...' : '')
        : currentThread.name;

    setWorkspaces((prev) =>
      prev.map((w) => {
        if (w.id === currentWorkspace.id) {
          return {
            ...w,
            threads: w.threads.map((t) =>
              t.id === currentThread.id
                ? {
                    ...t,
                    name: autoThreadTitle,
                    messages: updatedMessages,
                    updatedAt: userMessageTimestamp,
                  }
                : t
            ),
          };
        }
        return w;
      })
    );

    setIsLoading(true);
    const startTime = performance.now();

    let questionWithContext = trimmed;
    if (currentWorkspace.documents && currentWorkspace.documents.length > 0) {
      const docsContext = currentWorkspace.documents
        .map((d) => `[Document: ${d.name}]\n${d.content?.slice(0, 3000) || ''}`)
        .join('\n\n');
      questionWithContext = `[Context Information from workspace files]:\n${docsContext}\n\n[User Question]:\n${trimmed}`;
    }

    try {
      const res = await fetch(apiUrl('/api/ask-stream'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          question: questionWithContext,
          history: updatedMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          mode: 'Apolo Fast',
          model: 'Apolo 2.1',
          systemPrompt: currentWorkspace.systemPrompt,
          temperature: currentWorkspace.temperature,
        }),
      });

      let aiResponseText = '';

      if (res.ok && res.body) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let done = false;

        while (!done) {
          const { value, done: readerDone } = await reader.read();
          done = readerDone;
          if (value) {
            const chunk = decoder.decode(value, { stream: true });
            const lines = chunk.split('\n');
            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const dataStr = line.replace('data: ', '').trim();
                if (dataStr === '[DONE]') break;
                try {
                  const parsed = JSON.parse(dataStr);
                  if (parsed.text) aiResponseText += parsed.text;
                } catch {
                  aiResponseText += dataStr;
                }
              }
            }
          }
        }
      } else {
        const fallbackRes = await fetch(apiUrl('/api/chat'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            message: questionWithContext,
            mode: 'Sela Fast',
          }),
        });
        if (fallbackRes.ok) {
          const fallbackData = await fallbackRes.json();
          aiResponseText = fallbackData.reply || fallbackData.content || 'I have received your request.';
        } else {
          throw new Error('Server request failed.');
        }
      }

      const endTime = performance.now();
      const executionDuration = Math.max(0.4, (endTime - startTime) / 1000);
      const estimatedWords = aiResponseText.split(/\s+/).filter(Boolean).length;
      const estimatedTokens = Math.max(1, Math.round(estimatedWords * 1.33));
      const tokensPerSec = Math.max(1.0, estimatedTokens / executionDuration);
      const formattedTime = formatTelemetryDate(Date.now());

      const aiMessage: Message = {
        id: 'msg_' + Date.now(),
        role: 'model',
        content: aiResponseText || 'I am ready to help you with your tasks.',
        timestamp: Date.now(),
        modelUsed: 'Apolo 2.1',
        executionTime: parseFloat(executionDuration.toFixed(3)),
        tokensPerSecond: parseFloat(tokensPerSec.toFixed(2)),
        formattedTime,
      };

      setWorkspaces((prev) =>
        prev.map((w) => {
          if (w.id === currentWorkspace.id) {
            return {
              ...w,
              threads: w.threads.map((t) =>
                t.id === currentThread.id
                  ? {
                      ...t,
                      name: autoThreadTitle,
                      messages: [...updatedMessages, aiMessage],
                      updatedAt: Date.now(),
                    }
                  : t
              ),
            };
          }
          return w;
        })
      );
    } catch (err) {
      console.error('Send message error:', err);
      const errorMessage: Message = {
        id: 'msg_err_' + Date.now(),
        role: 'model',
        content: 'Unable to connect to the model service right now. Please try again in a moment.',
        timestamp: Date.now(),
        modelUsed: 'Apolo 2.1',
        executionTime: 0.12,
        tokensPerSecond: 1.0,
        formattedTime: formatTelemetryDate(Date.now()),
        isError: true,
      };

      setWorkspaces((prev) =>
        prev.map((w) => {
          if (w.id === currentWorkspace.id) {
            return {
              ...w,
              threads: w.threads.map((t) =>
                t.id === currentThread.id
                  ? {
                      ...t,
                      name: autoThreadTitle,
                      messages: [...updatedMessages, errorMessage],
                      updatedAt: Date.now(),
                    }
                  : t
              ),
            };
          }
          return w;
        })
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    const trimmed = inputText.trim();
    if (!trimmed || isLoading) return;
    setInputText('');
    await sendPromptWithHistory(trimmed, currentThread.messages);
  };

  const handleCopyMessage = (messageId: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedMessageId(messageId);
    setTimeout(() => {
      setCopiedMessageId((prev) => (prev === messageId ? null : prev));
    }, 2000);
  };

  const handleStartEdit = (message: Message) => {
    setEditingMessageId(message.id);
    setEditDraftText(message.content);
  };

  const handleCancelEdit = () => {
    setEditingMessageId(null);
    setEditDraftText('');
  };

  const handleSaveEdit = async (message: Message) => {
    const trimmed = editDraftText.trim();
    if (!trimmed) return;
    setEditingMessageId(null);
    setEditDraftText('');

    if (message.role === 'user') {
      const msgIndex = currentThread.messages.findIndex((m) => m.id === message.id);
      const priorMessages =
        msgIndex >= 0 ? currentThread.messages.slice(0, msgIndex) : currentThread.messages;
      await sendPromptWithHistory(trimmed, priorMessages);
    } else {
      setWorkspaces((prev) =>
        prev.map((w) =>
          w.id === currentWorkspace.id
            ? {
                ...w,
                threads: w.threads.map((t) =>
                  t.id === currentThread.id
                    ? {
                        ...t,
                        messages: t.messages.map((m) =>
                          m.id === message.id ? { ...m, content: trimmed } : m
                        ),
                      }
                    : t
                ),
              }
            : w
        )
      );
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const filteredHistoryThreads = currentWorkspace.threads.filter((t) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      t.name.toLowerCase().includes(q) ||
      t.messages.some((m) => m.content.toLowerCase().includes(q))
    );
  });

  return (
    <div className="flex h-[100dvh] w-screen overflow-hidden bg-[#050506] text-[#e5e7eb] font-sans antialiased p-2 sm:p-2.5 gap-2 sm:gap-3">
      {/* -------------------- SIDEBAR COLUMN (SMOOTH SPRING MOTION) -------------------- */}
      <AnimatePresence initial={false}>
        {isSidebarOpen && (
          <motion.aside
            key="sela-sidebar"
            initial={{ width: 0, opacity: 0, x: -24 }}
            animate={{ width: 258, opacity: 1, x: 0 }}
            exit={{ width: 0, opacity: 0, x: -24 }}
            transition={SMOOTH_SPRING}
            className="shrink-0 flex flex-col h-full z-30 select-none overflow-hidden"
          >
            {/* Top Brand Header (APOLO + split rectangle toggle) */}
            <div className="flex items-center justify-between px-3 pt-1 pb-3 min-w-[258px]">
              <div className="flex items-center gap-2.5">
                <span
                  style={{ fontFamily: "'Anton', 'Oswald', Impact, sans-serif" }}
                  className="text-[20px] tracking-[0.04em] text-white uppercase leading-none pt-0.5"
                >
                  APOLO
                </span>
              </div>

              {/* Sidebar toggle icon */}
              <motion.button
                whileHover={{ scale: 1.06 }}
                whileTap={{ scale: 0.92 }}
                type="button"
                onClick={() => setIsSidebarOpen(false)}
                className="p-1 text-zinc-400 hover:text-white transition-colors"
                title="Toggle sidebar"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.7"
                  className="w-5 h-5"
                >
                  <rect x="3" y="4" width="18" height="16" rx="2" />
                  <line x1="9" y1="4" x2="9" y2="20" />
                </svg>
              </motion.button>
            </div>

            {/* Rounded Sidebar Box Container */}
            <div className="flex-1 flex flex-col justify-between rounded-[18px] border border-[#222328] bg-[#0a0a0c] p-3 overflow-hidden min-w-[258px]">
              {/* Top section inside rounded box: Search + My Workspace + History */}
              <div className="flex flex-col flex-1 min-h-0 space-y-3">
                {/* Search bar + Solid White Plus Button */}
                <div className="flex items-center gap-2 shrink-0">
                  <div className="relative flex-1">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search"
                      className="w-full pl-8 pr-3 py-1.5 bg-[#1c1d21] rounded-lg text-xs text-zinc-200 placeholder-zinc-400 focus:outline-none transition-all duration-200 focus:ring-1 focus:ring-zinc-600"
                    />
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.94 }}
                    type="button"
                    onClick={handleQuickNewChat}
                    className="w-8 h-7 rounded-lg bg-white hover:bg-zinc-200 text-black flex items-center justify-center shrink-0 transition-colors"
                    title="New Chat"
                  >
                    <Plus className="w-4 h-4 stroke-[2.4]" />
                  </motion.button>
                </div>

                {/* My Workspace Bar (Settings button removed as selected) */}
                <div className="flex items-center justify-between px-2.5 py-2 rounded-md bg-[#1c1d21] hover:bg-[#232429] transition-colors shrink-0">
                  <div className="flex items-center gap-2 min-w-0">
                    <GripVertical className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
                    <span className="text-[12.5px] font-bold text-white truncate">
                      {currentWorkspace.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <motion.button
                      whileHover={{ scale: 1.08 }}
                      whileTap={{ scale: 0.92 }}
                      type="button"
                      onClick={() => setIsDocumentsModalOpen(true)}
                      className="p-0.5 text-zinc-400 hover:text-white transition-colors"
                      title="Upload documents"
                    >
                      <Upload className="w-3.5 h-3.5" />
                    </motion.button>
                  </div>
                </div>

                {/* Chat History Section */}
                <div className="flex flex-col flex-1 min-h-0 pt-1">
                  <div className="flex items-center justify-between px-1.5 pb-1.5">
                    <button
                      type="button"
                      onClick={() => setIsHistoryExpanded(!isHistoryExpanded)}
                      className="flex items-center gap-1.5 text-[11px] font-medium text-zinc-400 hover:text-white transition-colors"
                    >
                      <History className="w-3.5 h-3.5" />
                      <span>History</span>
                      <span className="text-[10px] text-zinc-500 font-mono">
                        ({filteredHistoryThreads.length})
                      </span>
                    </button>

                    {currentWorkspace.threads.length > 1 && (
                      <button
                        type="button"
                        onClick={handleClearAllHistory}
                        className="text-[10px] text-zinc-500 hover:text-zinc-300 transition-colors"
                        title="Clear all history"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  <AnimatePresence initial={false}>
                    {isHistoryExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
                        className="flex-1 overflow-y-auto space-y-1 pr-0.5"
                      >
                        {filteredHistoryThreads.map((thread) => {
                          const isActive = thread.id === currentWorkspace.activeThreadId;
                          return (
                            <motion.div
                              layout
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, scale: 0.96 }}
                              transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                              key={thread.id}
                              onClick={() => handleSelectThread(thread.id)}
                              className={`group flex items-center justify-between px-2.5 py-2 rounded-lg text-xs cursor-pointer transition-all duration-200 ${
                                isActive
                                  ? 'bg-[#1c1d22] text-white font-medium'
                                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#141519]'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <MessageSquare className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                                <span className="truncate">{thread.name}</span>
                              </div>

                              <button
                                type="button"
                                onClick={(e) => handleDeleteThread(e, thread.id)}
                                className="opacity-0 group-hover:opacity-100 p-1 rounded text-zinc-500 hover:text-red-400 transition-opacity shrink-0"
                                title="Delete chat"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </motion.div>
                          );
                        })}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              {/* Bottom Icon Bar (First 3 buttons removed as selected; only Wrench button remains) */}
              <div className="flex items-center justify-end px-1 pt-2 shrink-0">
                <motion.button
                  whileHover={{ scale: 1.08 }}
                  whileTap={{ scale: 0.92 }}
                  type="button"
                  onClick={() => setIsAuthModalOpen(true)}
                  className="w-9 h-9 rounded-full bg-[#1c1d21] hover:bg-[#282930] flex items-center justify-center text-white transition-colors"
                  title="Settings & Account"
                >
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                    <path d="M21.7 6.3a1 1 0 0 0-1.4 0l-2.6 2.6-2.6-2.6 2.6-2.6a1 1 0 0 0 0-1.4A6.5 6.5 0 0 0 9.1 9.5L3.3 15.3a2.4 2.4 0 0 0 0 3.4l2 2a2.4 2.4 0 0 0 3.4 0l5.8-5.8a6.5 6.5 0 0 0 7.2-8.6z" />
                  </svg>
                </motion.button>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* -------------------- MAIN CHAT ROUNDED PANEL -------------------- */}
      <motion.main
        layout
        transition={SMOOTH_SPRING}
        className="flex-1 flex flex-col h-full rounded-[18px] bg-[#141417] overflow-hidden relative"
      >
        {/* Top Bar inside Main Panel */}
        <header className="h-14 shrink-0 flex items-center justify-between px-6 z-20">
          <div>
            {!isSidebarOpen && (
              <motion.button
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.06 }}
                whileTap={{ scale: 0.92 }}
                type="button"
                onClick={() => setIsSidebarOpen(true)}
                className="p-1.5 text-zinc-400 hover:text-white transition-colors"
                title="Open sidebar"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.7"
                  className="w-5 h-5"
                >
                  <rect x="3" y="4" width="18" height="16" rx="2" />
                  <line x1="9" y1="4" x2="9" y2="20" />
                </svg>
              </motion.button>
            )}
          </div>
        </header>

        {/* Messages Stream View */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-4 space-y-6 scroll-smooth">
          <div className="max-w-[660px] mx-auto space-y-6">
            <AnimatePresence initial={false}>
              {currentThread.messages.map((message) => {
                const isAssistant = message.role === 'model';
                const isCopied = copiedMessageId === message.id;
                const isEditing = editingMessageId === message.id;

                if (isAssistant) {
                  const isSpeaking = speakingMessageId === message.id;

                  return (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
                      className="group space-y-2"
                    >
                      {isEditing ? (
                        <div className="bg-[#1e2026] border border-[#2d3039] rounded-xl p-3 space-y-2.5">
                          <textarea
                            value={editDraftText}
                            onChange={(e) => setEditDraftText(e.target.value)}
                            rows={3}
                            className="w-full bg-transparent text-sm text-white focus:outline-none resize-none leading-relaxed"
                          />
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={handleCancelEdit}
                              className="px-3 py-1 rounded-lg text-xs text-zinc-400 hover:text-white hover:bg-[#282a34] transition-colors"
                            >
                              Cancel
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSaveEdit(message)}
                              className="px-3 py-1 rounded-lg text-xs font-medium bg-white text-black hover:bg-zinc-200 transition-colors"
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-[15px] text-[#ededed] leading-relaxed break-words font-normal">
                          <MarkdownRenderer content={message.content} />
                        </div>
                      )}

                      <div className="flex items-center gap-1.5 pt-1 text-xs select-none">
                        <motion.button
                          whileHover={{ scale: 1.08 }}
                          whileTap={{ scale: 0.92 }}
                          type="button"
                          onClick={() => handleSpeak(message.id, message.content)}
                          className={`p-1.5 rounded-md transition-colors ${
                            isSpeaking
                              ? 'text-white bg-[#282a34]'
                              : 'text-zinc-500 hover:text-zinc-200 hover:bg-[#1f2128]'
                          }`}
                          title={isSpeaking ? 'Stop speaking' : 'Read aloud'}
                        >
                          {isSpeaking ? (
                            <VolumeX className="w-3.5 h-3.5 animate-pulse" />
                          ) : (
                            <Volume2 className="w-3.5 h-3.5" />
                          )}
                        </motion.button>

                        <motion.button
                          whileHover={{ scale: 1.08 }}
                          whileTap={{ scale: 0.92 }}
                          type="button"
                          onClick={() => handleCopyMessage(message.id, message.content)}
                          className="p-1.5 rounded-md text-zinc-500 hover:text-zinc-200 hover:bg-[#1f2128] transition-colors"
                          title="Copy message"
                        >
                          {isCopied ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </motion.button>

                        <motion.button
                          whileHover={{ scale: 1.08 }}
                          whileTap={{ scale: 0.92 }}
                          type="button"
                          onClick={() => handleStartEdit(message)}
                          className="p-1.5 rounded-md text-zinc-500 hover:text-zinc-200 hover:bg-[#1f2128] transition-colors"
                          title="Edit message"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </motion.button>
                      </div>
                    </motion.div>
                  );
                }

                return (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.26, ease: [0.22, 1, 0.36, 1] }}
                    className="group flex flex-col items-end space-y-1"
                  >
                    {isEditing ? (
                      <div className="w-full max-w-[85%] bg-[#1e2026] border border-[#2d3039] rounded-2xl p-3.5 space-y-2.5">
                        <textarea
                          value={editDraftText}
                          onChange={(e) => setEditDraftText(e.target.value)}
                          rows={2}
                          className="w-full bg-transparent text-sm text-white focus:outline-none resize-none leading-relaxed"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={handleCancelEdit}
                            className="px-3 py-1 rounded-lg text-xs text-zinc-400 hover:text-white hover:bg-[#282a34] transition-colors"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSaveEdit(message)}
                            className="px-3 py-1 rounded-lg text-xs font-medium bg-white text-black hover:bg-zinc-200 transition-colors"
                          >
                            Save & Submit
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="bg-[#25262c] text-white px-4 py-2.5 rounded-2xl max-w-[80%] text-[15px] leading-relaxed break-words">
                          {message.content}
                        </div>

                        <div className="flex items-center gap-1 opacity-80 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-200 pr-1">
                          <motion.button
                            whileHover={{ scale: 1.08 }}
                            whileTap={{ scale: 0.92 }}
                            type="button"
                            onClick={() => handleCopyMessage(message.id, message.content)}
                            className="p-1 rounded-md text-zinc-500 hover:text-zinc-200 hover:bg-[#1f2128] transition-colors"
                            title="Copy message"
                          >
                            {isCopied ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </motion.button>

                          <motion.button
                            whileHover={{ scale: 1.08 }}
                            whileTap={{ scale: 0.92 }}
                            type="button"
                            onClick={() => handleStartEdit(message)}
                            className="p-1 rounded-md text-zinc-500 hover:text-zinc-200 hover:bg-[#1f2128] transition-colors"
                            title="Edit message"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </motion.button>
                        </div>
                      </>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {isLoading && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center gap-2 text-xs text-zinc-500 py-2"
              >
                <Loader2 className="w-4 h-4 animate-spin text-zinc-400" />
                <span>Generating response...</span>
              </motion.div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* -------------------- BOTTOM INPUT COMPOSER -------------------- */}
        <div className="px-3 sm:px-4 pb-4 sm:pb-6 pt-2 shrink-0">
          <div className="max-w-[660px] mx-auto">
            <motion.div
              layout
              transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => {
                const target = e.target as HTMLElement;
                if (!target.closest('button')) {
                  textareaRef.current?.focus();
                }
              }}
              className="bg-[#1f2024] rounded-2xl px-4 sm:px-5 pt-3.5 sm:pt-4 pb-3 sm:pb-3.5 shadow-2xl cursor-text"
            >
              <textarea
                ref={textareaRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={1}
                inputMode="text"
                enterKeyHint="send"
                autoComplete="on"
                autoCorrect="on"
                autoCapitalize="sentences"
                placeholder=""
                className="w-full bg-transparent text-[16px] sm:text-[14.5px] text-white placeholder-zinc-500 focus:outline-none resize-none leading-relaxed min-h-[42px] max-h-[160px] select-text cursor-text"
              />

              {/* Bottom Toolbar inside composer */}
              <div className="flex items-center justify-between pt-2">
                {/* Left controls: + and @ Tools */}
                <div className="flex items-center gap-2.5">
                  <motion.button
                    whileHover={{ scale: 1.08 }}
                    whileTap={{ scale: 0.92 }}
                    type="button"
                    onClick={() => setIsDocumentsModalOpen(true)}
                    className="p-1 text-zinc-300 hover:text-white transition-colors"
                    title="Attach file or context"
                  >
                    <Plus className="w-4 h-4 stroke-[2]" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.95 }}
                    type="button"
                    onClick={() => setIsToolsModalOpen(true)}
                    className="flex items-center gap-1.5 py-1 text-[13px] text-zinc-300 hover:text-white transition-colors"
                    title="Agent tools"
                  >
                    <AtSign className="w-4 h-4 stroke-[2]" />
                    <span>Tools</span>
                  </motion.button>
                </div>

                {/* Right controls: Mic and circular Up Arrow */}
                <div className="flex items-center gap-2.5">
                  <motion.button
                    whileHover={{ scale: 1.08 }}
                    whileTap={{ scale: 0.92 }}
                    type="button"
                    onClick={handleToggleMic}
                    className={`p-1.5 rounded-full transition-colors ${
                      isListening
                        ? 'bg-red-500/20 text-red-400 animate-pulse'
                        : 'text-zinc-300 hover:text-white'
                    }`}
                    title={isListening ? 'Stop listening' : 'Voice input'}
                  >
                    <Mic className="w-4 h-4" />
                  </motion.button>

                  <motion.button
                    whileHover={{ scale: 1.06 }}
                    whileTap={{ scale: 0.92 }}
                    type="button"
                    onClick={handleSendMessage}
                    disabled={!inputText.trim() || isLoading}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${
                      inputText.trim() && !isLoading
                        ? 'bg-[#3e404a] hover:bg-[#4d505c] text-white'
                        : 'bg-[#363740] text-zinc-300'
                    }`}
                    title="Send message"
                  >
                    <ArrowUp className="w-4 h-4 stroke-[2]" />
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.main>

      {/* -------------------- MODALS -------------------- */}
      <WorkspaceSettingsModal
        isOpen={isWorkspaceSettingsOpen}
        workspace={currentWorkspace}
        onClose={() => setIsWorkspaceSettingsOpen(false)}
        onSave={handleUpdateWorkspace}
      />

      <DocumentsModal
        isOpen={isDocumentsModalOpen}
        documents={currentWorkspace.documents || []}
        onClose={() => setIsDocumentsModalOpen(false)}
        onAddDocument={handleAddDocument}
        onRemoveDocument={handleRemoveDocument}
      />

      <ToolsModal
        isOpen={isToolsModalOpen}
        activeTools={activeTools}
        onToggleTool={handleToggleTool}
        onClose={() => setIsToolsModalOpen(false)}
      />

      <LibraryModal
        isOpen={isLibraryModalOpen}
        onClose={() => setIsLibraryModalOpen(false)}
        onSelectPrompt={(prompt) => setInputText(prompt)}
      />

      <CommunityModal
        isOpen={isCommunityModalOpen}
        onClose={() => setIsCommunityModalOpen(false)}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={(user) => {
          setCurrentUser(user);
          setIsAuthModalOpen(false);
        }}
      />

      <SelaApiModal
        isOpen={isSelaApiModalOpen}
        onClose={() => setIsSelaApiModalOpen(false)}
      />
    </div>
  );
}
