import { Request, Response, NextFunction } from 'express';
import { getUserById, DbUser } from '../db/index.js';
import { verifyUserToken } from '../services/persona.js';

// Extend Express Request interface to include user
declare global {
  namespace Express {
    interface User extends DbUser {}
  }
}

export interface AuthenticatedRequest extends Request {
  user?: Express.User;
}

// Helper to resolve user from Bearer header if available
async function resolveUserFromHeader(req: Request): Promise<DbUser | null> {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7).trim();
    const userId = verifyUserToken(token);
    if (userId) {
      try {
        const user = await getUserById(userId);
        if (user) return user;
      } catch (e) {
        console.warn('[Token Auth Resolve Error]:', e);
      }
    }
  }
  return null;
}

export const requireAuth = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
) => {
  // 1. Check Passport authentication
  if (req.isAuthenticated && req.isAuthenticated() && req.user) {
    return next();
  }

  // 2. Check Bearer token from headers
  const tokenUser = await resolveUserFromHeader(req);
  if (tokenUser) {
    req.user = tokenUser;
    return next();
  }

  // 3. Check session userId if Passport didn't populate req.user
  const sessionUserId = (req.session as any)?.userId;
  if (sessionUserId) {
    try {
      const user = await getUserById(sessionUserId);
      if (user) {
        req.user = user;
        return next();
      }
    } catch (err) {
      console.error('[Auth Middleware Error]:', err);
    }
  }

  return res.status(401).json({
    error: 'Unauthorized: Please log in or sign up to access this feature.',
  });
};

export const optionalAuth = async (
  req: AuthenticatedRequest,
  _res: Response,
  next: NextFunction
) => {
  if (req.isAuthenticated && req.isAuthenticated() && req.user) {
    return next();
  }

  // Check Bearer token
  const tokenUser = await resolveUserFromHeader(req);
  if (tokenUser) {
    req.user = tokenUser;
    return next();
  }

  const sessionUserId = (req.session as any)?.userId;
  if (sessionUserId && !req.user) {
    try {
      const user = await getUserById(sessionUserId);
      if (user) {
        req.user = user;
      }
    } catch {
      // ignore
    }
  }

  return next();
};

