import rateLimit, { ipKeyGenerator } from 'express-rate-limit';

// Rate limiter for authentication endpoints to prevent brute-force attacks
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 30, // Limit each IP to 30 auth requests per windowMs
  standardHeaders: true, // Return rate limit info in `RateLimit-*` headers
  legacyHeaders: false, // Disable `X-RateLimit-*` headers
  // Custom keyGenerator to safely extract client IP behind reverse proxies (Cloud Run, load balancers)
  keyGenerator: (req) => {
    // Check standard Forwarded header (RFC 7239: for=192.0.2.60 or for="[2001:db8::1]")
    const forwarded = req.headers['forwarded'];
    if (typeof forwarded === 'string') {
      const match = forwarded.match(/for=(?:"?\[?)([^;,\s"\]]+)/i);
      if (match && match[1]) {
        return ipKeyGenerator(match[1]);
      }
    }
    // Check X-Forwarded-For header
    const xForwardedFor = req.headers['x-forwarded-for'];
    if (typeof xForwardedFor === 'string') {
      const firstIp = xForwardedFor.split(',')[0].trim();
      if (firstIp) {
        return ipKeyGenerator(firstIp);
      }
    }
    return ipKeyGenerator(req.ip || req.socket?.remoteAddress || '127.0.0.1');
  },
  validate: {
    xForwardedForHeader: false,
    forwardedHeader: false,
  },
  message: {
    error: 'Too many authentication attempts from this IP. Please try again in 15 minutes.',
  },
});

