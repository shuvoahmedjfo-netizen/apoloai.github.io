package com.askly.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
