import pg from 'pg';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';

const { Pool } = pg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface DbUser {
  id: number;
  name: string;
  email: string;
  password_hash: string | null;
  google_id: string | null;
  facebook_id: string | null;
  role: string;
  is_admin: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface DbChatMessage {
  id: number;
  user_id: number;
  role: 'user' | 'model' | 'assistant';
  message: string;
  created_at: Date;
}

let pool: pg.Pool | null = null;
let isPostgresConnected = false;

// Fallback in-memory state for local preview when DATABASE_URL is not yet connected
interface InMemoryStore {
  users: DbUser[];
  chatMessages: DbChatMessage[];
  userIdCounter: number;
  messageIdCounter: number;
}

const memoryStore: InMemoryStore = {
  users: [],
  chatMessages: [],
  userIdCounter: 1,
  messageIdCounter: 1,
};

export function getPool(): pg.Pool | null {
  return pool;
}

export function isDbConnected(): boolean {
  return isPostgresConnected;
}

export const DEFAULT_ADMINS = [
  {
    name: 'Hadiuzzaman Shuvo',
    email: 'hadiuzzamanfora@gmail.com',
    password: 'shuvofora',
  },
  {
    name: 'Hadiuzzaman Shuvo',
    email: 'hadiuzzamanmuntasir2@gmail.com',
    password: 'shuvofora',
  },
];

export async function seedAdminUsers(): Promise<void> {
  for (const admin of DEFAULT_ADMINS) {
    const normalizedEmail = admin.email.trim().toLowerCase();
    const hash = await bcrypt.hash(admin.password, 10);

    if (isPostgresConnected && pool) {
      try {
        const check = await pool.query(
          'SELECT id FROM users WHERE LOWER(email) = LOWER($1)',
          [normalizedEmail]
        );
        if (check.rows.length === 0) {
          await pool.query(
            `INSERT INTO users (name, email, password_hash, role, is_admin, created_at, updated_at)
             VALUES ($1, $2, $3, 'admin', true, NOW(), NOW())`,
            [admin.name, normalizedEmail, hash]
          );
          console.log(`[Admin Seed] Admin user ${normalizedEmail} created in PostgreSQL.`);
        } else {
          await pool.query(
            `UPDATE users
             SET name = $1, password_hash = $2, role = 'admin', is_admin = true, updated_at = NOW()
             WHERE LOWER(email) = LOWER($3)`,
            [admin.name, hash, normalizedEmail]
          );
          console.log(`[Admin Seed] Admin user ${normalizedEmail} credentials updated in PostgreSQL.`);
        }
      } catch (err: any) {
        console.warn(`[Admin Seed Warning] Could not seed ${normalizedEmail} in PostgreSQL:`, err.message);
      }
    } else {
      // Memory store fallback
      const existing = memoryStore.users.find((u) => u.email.toLowerCase() === normalizedEmail);
      if (!existing) {
        memoryStore.users.push({
          id: memoryStore.userIdCounter++,
          name: admin.name,
          email: normalizedEmail,
          password_hash: hash,
          google_id: null,
          facebook_id: null,
          role: 'admin',
          is_admin: true,
          created_at: new Date(),
          updated_at: new Date(),
        });
        console.log(`[Admin Seed] Admin user ${normalizedEmail} seeded in-memory.`);
      } else {
        existing.name = admin.name;
        existing.password_hash = hash;
        existing.role = 'admin';
        existing.is_admin = true;
        existing.updated_at = new Date();
      }
    }
  }
}

export async function initDatabase(): Promise<void> {
  const databaseUrl = process.env.DATABASE_URL;

  if (!databaseUrl) {
    console.log(
      '[Database Notice] DATABASE_URL is not set in environment. Running in-memory database store for local dev. Set DATABASE_URL in .env to connect to PostgreSQL.'
    );
    await seedAdminUsers();
    return;
  }

  try {
    pool = new Pool({
      connectionString: databaseUrl,
      ssl:
        process.env.NODE_ENV === 'production' && !databaseUrl.includes('localhost')
          ? { rejectUnauthorized: false }
          : false,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
    });

    pool.on('error', (err) => {
      console.error('[PostgreSQL Pool Error]:', err.message);
    });

    // Test connection
    const client = await pool.connect();
    try {
      // Execute schema migration
      const schemaPath = path.join(__dirname, 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schemaSql = fs.readFileSync(schemaPath, 'utf8');
        await client.query(schemaSql);
        console.log('[Database] PostgreSQL schema migration verified successfully.');
      }
      isPostgresConnected = true;
      console.log('[Database] Connected to PostgreSQL successfully.');
    } finally {
      client.release();
    }
  } catch (err: any) {
    console.warn(
      `[Database Warning] Could not connect to PostgreSQL at DATABASE_URL (${err.message}). Using in-memory fallback store for preview.`
    );
    isPostgresConnected = false;
  }

  // Seed or update the configured admin users on startup
  await seedAdminUsers();
}

// User queries with parameterized queries
export async function getUserById(id: number): Promise<DbUser | null> {
  if (isPostgresConnected && pool) {
    const res = await pool.query<DbUser>(
      `SELECT id, name, email, password_hash, google_id, facebook_id,
              COALESCE(role, 'user') AS role,
              COALESCE(is_admin, false) AS is_admin,
              created_at, updated_at
       FROM users WHERE id = $1 LIMIT 1`,
      [id]
    );
    return res.rows[0] || null;
  }

  const user = memoryStore.users.find((u) => u.id === id);
  return user || null;
}

export async function getUserByEmail(email: string): Promise<DbUser | null> {
  const normalizedEmail = email.trim().toLowerCase();
  if (isPostgresConnected && pool) {
    const res = await pool.query<DbUser>(
      `SELECT id, name, email, password_hash, google_id, facebook_id,
              COALESCE(role, 'user') AS role,
              COALESCE(is_admin, false) AS is_admin,
              created_at, updated_at
       FROM users WHERE LOWER(email) = LOWER($1) LIMIT 1`,
      [normalizedEmail]
    );
    return res.rows[0] || null;
  }

  const user = memoryStore.users.find(
    (u) => u.email.toLowerCase() === normalizedEmail
  );
  return user || null;
}

export async function getUserByGoogleId(googleId: string): Promise<DbUser | null> {
  if (isPostgresConnected && pool) {
    const res = await pool.query<DbUser>(
      `SELECT id, name, email, password_hash, google_id, facebook_id,
              COALESCE(role, 'user') AS role,
              COALESCE(is_admin, false) AS is_admin,
              created_at, updated_at
       FROM users WHERE google_id = $1 LIMIT 1`,
      [googleId]
    );
    return res.rows[0] || null;
  }

  const user = memoryStore.users.find((u) => u.google_id === googleId);
  return user || null;
}

export async function getUserByFacebookId(facebookId: string): Promise<DbUser | null> {
  if (isPostgresConnected && pool) {
    const res = await pool.query<DbUser>(
      `SELECT id, name, email, password_hash, google_id, facebook_id,
              COALESCE(role, 'user') AS role,
              COALESCE(is_admin, false) AS is_admin,
              created_at, updated_at
       FROM users WHERE facebook_id = $1 LIMIT 1`,
      [facebookId]
    );
    return res.rows[0] || null;
  }

  const user = memoryStore.users.find((u) => u.facebook_id === facebookId);
  return user || null;
}

export async function createUser(params: {
  name: string;
  email: string;
  passwordHash?: string | null;
  googleId?: string | null;
  facebookId?: string | null;
  role?: string;
  isAdmin?: boolean;
}): Promise<DbUser> {
  const normalizedEmail = params.email.trim().toLowerCase();
  const role = params.role || (params.isAdmin ? 'admin' : 'user');
  const isAdmin = params.isAdmin || role === 'admin';

  if (isPostgresConnected && pool) {
    const res = await pool.query<DbUser>(
      `INSERT INTO users (name, email, password_hash, google_id, facebook_id, role, is_admin, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
       RETURNING id, name, email, password_hash, google_id, facebook_id, role, is_admin, created_at, updated_at`,
      [
        params.name.trim(),
        normalizedEmail,
        params.passwordHash || null,
        params.googleId || null,
        params.facebookId || null,
        role,
        isAdmin,
      ]
    );
    return res.rows[0];
  }

  const newUser: DbUser = {
    id: memoryStore.userIdCounter++,
    name: params.name.trim(),
    email: normalizedEmail,
    password_hash: params.passwordHash || null,
    google_id: params.googleId || null,
    facebook_id: params.facebookId || null,
    role,
    is_admin: isAdmin,
    created_at: new Date(),
    updated_at: new Date(),
  };

  memoryStore.users.push(newUser);
  return newUser;
}

export async function linkOAuthAccount(
  userId: number,
  params: { googleId?: string; facebookId?: string; name?: string }
): Promise<DbUser | null> {
  if (isPostgresConnected && pool) {
    const updates: string[] = ['updated_at = NOW()'];
    const values: any[] = [userId];
    let paramIndex = 2;

    if (params.googleId) {
      updates.push(`google_id = $${paramIndex++}`);
      values.push(params.googleId);
    }
    if (params.facebookId) {
      updates.push(`facebook_id = $${paramIndex++}`);
      values.push(params.facebookId);
    }
    if (params.name) {
      updates.push(`name = COALESCE(name, $${paramIndex++})`);
      values.push(params.name);
    }

    const query = `
      UPDATE users
      SET ${updates.join(', ')}
      WHERE id = $1
      RETURNING id, name, email, password_hash, google_id, facebook_id,
                COALESCE(role, 'user') AS role,
                COALESCE(is_admin, false) AS is_admin,
                created_at, updated_at
    `;

    const res = await pool.query<DbUser>(query, values);
    return res.rows[0] || null;
  }

  const user = memoryStore.users.find((u) => u.id === userId);
  if (user) {
    if (params.googleId) user.google_id = params.googleId;
    if (params.facebookId) user.facebook_id = params.facebookId;
    if (params.name && !user.name) user.name = params.name;
    user.updated_at = new Date();
  }
  return user || null;
}

// Chat Messages Queries
export async function saveChatMessage(params: {
  userId: number;
  role: 'user' | 'model' | 'assistant';
  message: string;
}): Promise<DbChatMessage> {
  if (isPostgresConnected && pool) {
    const res = await pool.query<DbChatMessage>(
      `INSERT INTO chat_messages (user_id, role, message, created_at)
       VALUES ($1, $2, $3, NOW())
       RETURNING id, user_id, role, message, created_at`,
      [params.userId, params.role, params.message]
    );
    return res.rows[0];
  }

  const newMsg: DbChatMessage = {
    id: memoryStore.messageIdCounter++,
    user_id: params.userId,
    role: params.role,
    message: params.message,
    created_at: new Date(),
  };

  memoryStore.chatMessages.push(newMsg);
  return newMsg;
}

export async function getUserChatHistory(
  userId: number,
  limit: number = 100
): Promise<DbChatMessage[]> {
  if (isPostgresConnected && pool) {
    const res = await pool.query<DbChatMessage>(
      `SELECT id, user_id, role, message, created_at
       FROM chat_messages
       WHERE user_id = $1
       ORDER BY created_at ASC
       LIMIT $2`,
      [userId, limit]
    );
    return res.rows;
  }

  return memoryStore.chatMessages
    .filter((m) => m.user_id === userId)
    .sort((a, b) => a.created_at.getTime() - b.created_at.getTime())
    .slice(-limit);
}

export async function clearUserChatHistory(userId: number): Promise<void> {
  if (isPostgresConnected && pool) {
    await pool.query('DELETE FROM chat_messages WHERE user_id = $1', [userId]);
    return;
  }

  memoryStore.chatMessages = memoryStore.chatMessages.filter(
    (m) => m.user_id !== userId
  );
}
